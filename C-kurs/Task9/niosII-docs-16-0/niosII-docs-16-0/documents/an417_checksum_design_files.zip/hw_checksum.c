/******************************************************************************
* Copyright � 2006 Altera Corporation, San Jose, California, USA.             *
* All rights reserved. All use of this software and documentation is          *
* subject to the License Agreement located at the end of this file below.     *
*******************************************************************************
* Author - JCJB                                                               *
*                                                                             *
* Based on the "Portable C implementation of the Internet checksum", derived  *
* from Braden, Borman, and Partridge's example implementation in RFC 1071.    *
* This function will be passed a lookup table block and perform scatter       *
* gather DMA reads on the data to be summed.  Since it performs calculations  *
* across multiple buffers this function has no return value so it returns     *
* the results via a pre-allocated return value buffer                         *
*                                                                             *
* Inputs:  unsigned short *:  Base address of the buffer map table            *
*          unsigned long:     Length of the buffer map table                  *
*          unsigned short *:  Storage space for the returned values           *
* Outputs: void:  The caller will be responsible for reading the results      *
*******************************************************************************/

/* sdram has a different name on the Cyclone II board */
#include "system.h"

#ifdef SDRAM_BASE
  #pragma altera_accelerate connect_variable hw_checksum/addr to sdram
  #pragma altera_accelerate connect_variable hw_checksum/table_address to sdram
  #pragma altera_accelerate connect_variable hw_checksum/return_values to sdram
#elif DDR_SDRAM_BASE
  #pragma altera_accelerate connect_variable hw_checksum/addr to ddr_sdram
  #pragma altera_accelerate connect_variable hw_checksum/table_address to ddr_sdram
  #pragma altera_accelerate connect_variable hw_checksum/return_values to ddr_sdram
#elif DDR_SDRAM_0_BASE
  #pragma altera_accelerate connect_variable hw_checksum/addr to ddr_sdram_0
  #pragma altera_accelerate connect_variable hw_checksum/table_address to ddr_sdram_0
  #pragma altera_accelerate connect_variable hw_checksum/return_values to ddr_sdram_0
#else
#error Compilation failure:  Please rename the main memory in your system to be sdram or ddr_sdram
#endif



void hw_checksum(unsigned long * table_address, unsigned long table_length,
                 unsigned short * return_values)
{
  void * addr;
  unsigned long buffer_ctr;  
  unsigned long count;
  unsigned long temp_data;
  unsigned long sum;


  /*******************************************************************
   * Scatter gather DMA loop                                         *
   *                                                                 *
   * Use "addr" to perform read operations on the memory and "count" *
   * to keep track of the length of the buffer.  These values are    *
   * loaded from the table using the pointer "table_address" which   *
   * has a length "table_length".   
   *******************************************************************/
  for(buffer_ctr = 0; buffer_ctr < table_length; buffer_ctr++)
  {
    /* read in the next base address and length of the buffer */
    addr = (void *)(*table_address++);   /* buffer address */
    count = *table_address++;            /* buffer length  */
    
/*TRANSORMATION******************************************************/
    
    /*****************************************************************
     * Begining of the checksum transformation.  You can replace the *
     * checksum with your own transformation re-using the scatter    *
     * gather DMA.                                                   *
     *****************************************************************/
    sum = 0;
    /*****************************************************************
     * Using the scatter gather DMA access the memory 32 bits at a   *
     * time.  Split the word into half words and add these to the    *
     * accumulator "sum".  Count is expressed in bytes so it must    *
     * decrease by 4 bytes per word access.  The pointer "addr" must *
     * advance by 4 bytes per word access                            *
     *****************************************************************/
    while (count > 3) {
      temp_data = *(unsigned long *)addr;
      sum += (temp_data & 0xFFFF) + ((temp_data & 0xFFFF0000) >> 16);
      count -= 4;
      addr += 4;
    }
  
    /* Add left-over half word when applicable.  This is a half      *
     * word access so the pointer "addr" must advance by 2           */
    sum += ((count == 2) || (count == 3))? *(unsigned short*)addr : 0;  
    addr += ((count == 2) || (count == 3))? 2 : 0;

    /* Add left-over byte when applicable.  This is the last         *
     * possible access so no need to move the pointer "addr"         */
    sum += ((count == 1) || (count == 3))? *(unsigned char *)addr : 0;
  
    /* Fold 32-bit sum to 16 bits.  The first fold could result in   *
     * a 17 bit sum so a second fold guarantees that the result      *
     * fits within 16 bits                                           */  
      
    /* 1st fold */
    sum = (sum & 0xffff) + (sum >> 16);
    /* 2nd fold */
    return_values[buffer_ctr] = ~((sum & 0xffff) + (sum >> 16));  
/*END OF TRANSFORMATION***********************************************/
  }
}

/******************************************************************************
*                                                                             *
* License Agreement                                                           *
*                                                                             *
* Copyright (c) 2006 Altera Corporation, San Jose, California, USA.           *
* All rights reserved.                                                        *
*                                                                             *
* Permission is hereby granted, free of charge, to any person obtaining a     *
* copy of this software and associated documentation files (the "Software"),  *
* to deal in the Software without restriction, including without limitation   *
* the rights to use, copy, modify, merge, publish, distribute, sublicense,    *
* and/or sell copies of the Software, and to permit persons to whom the       *
* Software is furnished to do so, subject to the following conditions:        *
*                                                                             *
* The above copyright notice and this permission notice shall be included in  *
* all copies or substantial portions of the Software.                         *
*                                                                             *
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR  *
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,    *
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE *
* AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER      *
* LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING     *
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER         *
* DEALINGS IN THE SOFTWARE.                                                   *
*                                                                             *
* This agreement shall be governed in all respects by the laws of the State   *
* of California and by the laws of the United States of America.              *
* Altera does not recommend, suggest or require that this reference design    *
* file be used in conjunction or combination with any other product.          *
******************************************************************************/
