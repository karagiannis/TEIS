/******************************************************************************
* Copyright � 2006 Altera Corporation, San Jose, California, USA.             *
* All rights reserved. All use of this software and documentation is          *
* subject to the License Agreement located at the end of this file below.     *
*******************************************************************************
* Author - JCJB                                                               *
*                                                                             *
* This example software can target any standard or full-featured design.      *
* It must be compiled to use the SDRAM/DDR SDRAM memory via the memory        *
* settings available within the system library project.  Within the system    *
* library project settings be sure to set the timestamp timer to use the      *
* "high_res_timer" so that accurate time measurements can be made.            *
*                                                                             *
* ### CAUTION! ###                                                            *
*                                                                             *
* These design files were tested using the "standard" and "full-featured"     *
* example designs.  If you use any other design be aware that the high        *
* resolution timer could overflow and cause an incorrect time measurement.    *
* In this case reduce the resolution of the timer or reduce the number of     *
* data buffers or test iterations used.                                       *
*******************************************************************************/

#include "system.h"
#include "stdio.h"
#include "sys/alt_timestamp.h"
#include "stdlib.h"
#include "sys/alt_cache.h"

/******************************************************************************
* ### MAKE MODIFICATIONS HERE ###                                             *
* ### Control the test using these defined values ###                         *
*                                                                             *
* Don't go overboard with these numbers or you may run out of memory          *
* Maximum memory usued = NUMBER_OF_BUFFERS * MAX_BUFFER_LENGTH [bytes]        *
*******************************************************************************/
#define NUMBER_OF_BUFFERS 50    /* number of dynamically allocated buffers    */
#define MAX_BUFFER_LENGTH 1500  /* maximum buffer size in bytes               */
#define MIN_BUFFER_LENGTH 64    /* minimum buffer size in bytes               */
#define TEST_ITERATIONS   1000  /* repeats the test this many times           */
#define SHOW_ALL_RESULTS  0     /* set to 1 if you want to see all results    */
/* set to 0 if you want each buffer to have a length of MAX_BUFFER_LENGTH     */
#define ENABLE_RANDOM_LENGTH  1



/* prototype for the hardware accelerator source code */
void hw_checksum(unsigned long * table_address, unsigned long table_length,
                 unsigned short * return_values);


/******************************************************************************
* Portable C implementation of the Internet checksum, derived                 *
* from Braden, Borman, and Partridge's example implementation                 *
* in RFC 1071.                                                                *
*                                                                             *
* Inputs:  unsigned short *:  base address of the buffer to be summed         *
*          int:               length of the buffer to be summed               *
* Outputs: unsigned short:    calculated 16 bit checksum                      *
*******************************************************************************/
unsigned short sw_checksum(unsigned short * addr, int count)
{
  /* Compute Internet Checksum for "count" bytes
  *         beginning at location "addr".
  */
  register long sum = 0;

  while( count > 1 )  {
  /*  This is the inner loop */
    sum += *addr++; /* JCJB:  the line from RFC 1071 example was incorrect */
    count -= 2;
  }

  /*  Add left-over byte, if any */
  if( count > 0 )
    sum += * (unsigned char *)addr;

  /*  Fold 32-bit sum to 16 bits */
  while (sum>>16)
    sum = (sum & 0xffff) + (sum >> 16);

  return (~sum);
}




/******************************************************************************
* Main benchmark                                                              *
*                                                                             *
* - Generates linearly data at dynamically allocated buffer locations         *
* - Calls software and hardware versions of the checksum algorithm on the     *
*   buffers previously created                                                *
* - Report is output to the user                                              *
*******************************************************************************/
int main()
{
  unsigned short software_results[NUMBER_OF_BUFFERS];
  unsigned short hardware_results[NUMBER_OF_BUFFERS];
  unsigned long buf_counter, buf_length, test_counter;
  unsigned long buffer_map[2*NUMBER_OF_BUFFERS];
  unsigned char *temp_data_ptr;
  unsigned char temp_data;
  unsigned char results_check;
  unsigned long sw_time_1, sw_time_2, hw_time_1, hw_time_2;

  /***********************************************
   * Output the test setup                       *
   ***********************************************/
  printf("Test setup:\n");
  printf("Number of buffers:  %u\n", NUMBER_OF_BUFFERS);
  if(ENABLE_RANDOM_LENGTH == 1)
    printf("Variable number of bytes per buffer between %u and %u\n", MIN_BUFFER_LENGTH, MAX_BUFFER_LENGTH);    
  else
    printf("Number of bytes per buffer:  %u\n", MAX_BUFFER_LENGTH);

  printf("Total number of test iterations:  %u\n\n", TEST_ITERATIONS);

  /* get the timestamp started so it can seed the random number generator     */
  if(alt_timestamp_start() < 0)
  {
    printf("Please add the high resolution timer to the timestamp timer setting in the syslib properties page.\n");
    return 0;
  }

  /***********************************************
   * Initialize the test data                    *
   ***********************************************/
   
  /****************************************************************************
   * Buffer table format:                                                     *
   *                                                                          *
   * Buffer  |  Base Address  |  Length                                       *
   *   1     |      A0        |    L0                                         *
   *   2     |      A1        |    L1                                         *
   * ......                                                                   *
   *   N     |      A(N-1)    |    L(N-1)                                     *
   *                                                                          *
   * Where N = NUMBER_OF_BUFFERS                                              *
   ****************************************************************************/
  printf("Initializing the data.\n\n");
  srand(alt_timestamp());  /* seed based off the timestamp value */
  temp_data = 0;
  for(buf_counter = 0; buf_counter < NUMBER_OF_BUFFERS; buf_counter++)
  {
    /* create a buffer length between the MAX and MIN buffer lengths */
    if(ENABLE_RANDOM_LENGTH == 1)
      buffer_map[2*buf_counter + 1] = (unsigned long)((rand() % (MAX_BUFFER_LENGTH - MIN_BUFFER_LENGTH)) + MIN_BUFFER_LENGTH);
    else  /* controlled test using MAX_BUFFER_LENGTH for all buffers */
      buffer_map[2*buf_counter + 1] = (unsigned long)MAX_BUFFER_LENGTH;      

    /* allocate the memory for buffer to populate */
    temp_data_ptr = malloc(buffer_map[2*buf_counter+1]);
    if(temp_data_ptr == NULL)
    {
      printf("Insufficient memory to run test.  Please adjust the test\n");
      printf("parameters near the top of the source to correct this\n");
      return 0;
    }

    /* store the allocated buffer memory to the table */    
    buffer_map[2*buf_counter] = (unsigned long)temp_data_ptr;

    /* populate the buffer with linear data values with increasing slope */    
    for(buf_length = 0; buf_length < buffer_map[2*buf_counter + 1]; buf_length++)
    {   
      temp_data = (temp_data + buf_counter + 1) & 0xFF;  
      *temp_data_ptr = temp_data;
      temp_data_ptr++;
    }
  }


  /***********************************************
   * Run the software checksum on the data       *
   ***********************************************/ 
  printf("Running the software version of the checksum.  Please be patient.\n\n");
  sw_time_1 = alt_timestamp();
  for(test_counter = 0; test_counter < TEST_ITERATIONS; test_counter++)
  {
    for(buf_counter = 0; buf_counter < NUMBER_OF_BUFFERS; buf_counter++)
    {
      software_results[buf_counter] = sw_checksum((unsigned short *)buffer_map[2*buf_counter], (int)buffer_map[2*buf_counter+1]);  
    }
  }
  sw_time_2 = alt_timestamp();

  /* if a data cache is present then this flush is necessary to avoid cache
   * coherency problems
   */
  #if (NIOS2_DCACHE_SIZE > 0)
    alt_dcache_flush_all();
  #endif

  /***********************************************
   * Run the hardware checksum on the data       *
   ***********************************************/
  printf("Running the hardware version of the checksum.\n\n");
  hw_time_1 = alt_timestamp();
  for(test_counter = 0; test_counter < TEST_ITERATIONS; test_counter++)
  {
    hw_checksum(buffer_map, NUMBER_OF_BUFFERS, hardware_results); 
  }
  hw_time_2 = alt_timestamp();
   
   
  /*********************************************** 
   * Output results from the SW and HW tests     *
   ***********************************************/
  printf("Test Results:\n\n");
  results_check = 1;
  for(buf_counter = 0; buf_counter < NUMBER_OF_BUFFERS; buf_counter++)
  {
    /* This will output all results if you want it to */
    if(SHOW_ALL_RESULTS == 1)
      printf("SW Results: %u, HW Results: %u\n", software_results[buf_counter], hardware_results[buf_counter]);

    /* Make sure that the hardware results match the software results */
    if(software_results[buf_counter] != hardware_results[buf_counter])
      results_check = 0;
  }  
  
  if(results_check == 1)
    printf("The results for both the software and hardware checksums match\n");
  else
    printf("The results for the software and hardware checksums do not match\n");    

  printf("Software processing time was: %f seconds\n", ((double)(sw_time_2-sw_time_1))/((double)alt_timestamp_freq()));
  printf("Hardware processing time was: %f seconds\n", ((double)(hw_time_2-hw_time_1))/((double)alt_timestamp_freq()));  
  printf("Hardware speedup factor over the software implementation was: %.2f times\n", ((double)(sw_time_2-sw_time_1))/((double)(hw_time_2-hw_time_1)));
  return 1;
}

/******************************************************************************
*                                                                             *
* License Agreement                                                           *
*                                                                             *
* Copyright (c) 2006 Altera Corporation, San Jose, California, USA.           *
* All rights reserved.                                                        *
*                                                                             *
* Permission is hereby granted, free of charge, to any person obtaining a     *
* copy of this software and associated documentation files (the "Software"),  *
* to deal in the Software without restriction, including without limitation   *
* the rights to use, copy, modify, merge, publish, distribute, sublicense,    *
* and/or sell copies of the Software, and to permit persons to whom the       *
* Software is furnished to do so, subject to the following conditions:        *
*                                                                             *
* The above copyright notice and this permission notice shall be included in  *
* all copies or substantial portions of the Software.                         *
*                                                                             *
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR  *
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,    *
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE *
* AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER      *
* LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING     *
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER         *
* DEALINGS IN THE SOFTWARE.                                                   *
*                                                                             *
* This agreement shall be governed in all respects by the laws of the State   *
* of California and by the laws of the United States of America.              *
* Altera does not recommend, suggest or require that this reference design    *
* file be used in conjunction or combination with any other product.          *
******************************************************************************/
