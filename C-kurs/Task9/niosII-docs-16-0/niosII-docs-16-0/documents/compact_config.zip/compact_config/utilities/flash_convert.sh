#!/bin/sh

#Refer to comments with MOD heading if you wish to change this script

  # Check the number of arguments passed into the script
  #MOD: Change the number of arguments if you have extra sof files to be converted
  if [ $# -ne 4 ] ; then
    echo ""
    echo "ERROR: There must be four arguments passed to this script."
    echo ""
    echo "USAGE: ./flash_convert.sh <sof_1> <sof_2> <offset_1> <offset_2>"
    echo " <sof_1>     = Factory Image SOF file"
    echo " <sof_2>     = Application Image SOF file"
	echo " <offset_1>  = Factory Image flash offset"
	echo " <offset_2>  = Application Image flash offset"
    echo ""
    exit 1;
  fi

  # Check that the input files actually exists before we proceed  
  #MOD: Adds extra arguments so that all sofs file are checked for existance before proceed
  for argument in "$1" "$2"
  do
    if [ ! -e $argument ] ; then
      echo ""
      echo "ERROR: Cannot find file $argument."
      echo ""
      exit 1;
    fi
  done

# Grab the base names of the .elf and sof files.
#MOD: Adds new variables here
sofbase1=$(echo $1 | sed 's/\.sof//')
sofbase2=$(echo $2 | sed 's/\.sof//')

# Perform the file conversions
#MOD: Adds new sof2flash command here
sof2flash --activeparallel --input=$1 --output=$sofbase1\.flash --offset=$3
sof2flash --activeparallel --input=$2 --output=$sofbase2\.flash --offset=$4

#Combine into a single .flash file
#MOD: Put your .flash files name and path before the '>' sign
cat $sofbase1\.flash $sofbase2\.flash > temp.flash

#Remove non-data records in the combined flash file
#Data record types, are S1, S2, and S3, so you want to remove all the other types of records (S0, S5, S7, S8, and S9).
sed '/^S[05789]/ d' temp.flash > output.flash

#Remove all temporary files
rm temp.flash

echo "Flash conversion is completed."