#!/bin/sh


  # Check the number of arguments passed into the script
  #
  if [ $# -ne 2 ] ; then
    echo ""
    echo "ERROR: There must be two arguments passed to this script."
    echo ""
    echo "USAGE: ./program_flash.sh <flash file> <cable name>"
    echo " <flash file> = The .flash file to be programmed"
	echo " <cable name> = Specify the JTAG cable to be used"
    echo ""
    exit 1;
  fi
  
#Check if the program_flash.sof is exists in the directory
if [ ! -e ./program_flash.sof ] ; then
      echo ""
      echo "ERROR: Cannot find file program_flash.sof."
      echo ""
      exit 1;
fi

#Configure the FPGA with program_flash.sof
nios2-configure-sof program_flash.sof --cable="$2"

				if [ $? -ne 0 ] ; then
                  echo ""
                  echo "ERROR: trying to configure SOF file"
                  echo ""
                  echo "Make sure cable name is included in double quotes"
                  echo ""                  
                  exit 1;
                fi

#Start programming the flash device
nios2-flash-programmer --base=0x2000000 --cable="$2" $1 --go

				if [ $? -ne 0 ] ; then
                  echo ""
                  echo "ERROR: trying to program flash"
                  echo ""
                  echo "Make sure cable name is included in double quotes"
                  echo ""                  
                  exit 1;
                fi
				
echo "Flash programming is completed."
