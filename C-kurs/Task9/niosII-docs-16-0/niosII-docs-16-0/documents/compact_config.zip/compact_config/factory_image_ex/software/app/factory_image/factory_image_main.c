#include <unistd.h>
#include "sys/alt_irq.h"
#include "alt_types.h"
#include "altera_avalon_pio_regs.h"
#include "system.h"
#include "io.h"

/*Change this define value to turn on or off the message printing operations*/
#define USE_JTAG_UART 1

/*Excluding this library file if message printing is not needed*/
#if USE_JTAG_UART	
	#include "sys/alt_stdio.h"
#endif

/*Application image offset*/
#define hw_flash_offset 0xA00000

/* A variable to hold the value of the button pio edge capture register. */
volatile int edge_capture;

/*******************************************************************
 * static void handle_button_interrupts( void* context, alt_u32 id)*
 *                                                                 *  
 * Handle interrupts from the buttons.                             *
 * This interrupt event is triggered by a button/switch press.     *
 * This handler sets *context to the value read from the button    *
 * edge capture register.  The button edge capture register        *
 * is then cleared and normal program execution resumes.           *
 * The value stored in *context is used to control program flow    *
 * in the rest of this program's routines.                         *
 ******************************************************************/
static void handle_button_interrupts(void* context, alt_u32 id)
{
    /* Cast context to edge_capture's type. It is important that this be 
     * declared volatile to avoid unwanted compiler optimization.
     */
    volatile int* edge_capture_ptr = (volatile int*) context;
    /* Store the value in the Button's edge capture register in *context. */
    *edge_capture_ptr = IORD_ALTERA_AVALON_PIO_EDGE_CAP(BUTTON_BASE);
    /* Reset the Button's edge capture register. */
    IOWR_ALTERA_AVALON_PIO_EDGE_CAP(BUTTON_BASE, 0);
}

/* Initialize the button_pio. */

static void init_button_pio()
{
    /* Recast the edge_capture pointer to match the alt_irq_register() function
     * prototype. */
    void* edge_capture_ptr = (void*) &edge_capture;
    /* Enable all 4 button interrupts. */
    IOWR_ALTERA_AVALON_PIO_IRQ_MASK(BUTTON_BASE, 0xf);
    /* Reset the edge capture register. */
    IOWR_ALTERA_AVALON_PIO_EDGE_CAP(BUTTON_BASE, 0x0);
    /* Register the interrupt handler. */
    alt_irq_register( BUTTON_IRQ, edge_capture_ptr,
                      handle_button_interrupts );
}


int main()
{
  /* Initialize the button pio. */
  init_button_pio();
  
  #if USE_JTAG_UART
  alt_putstr("Running Factory Image\n");
  alt_putstr("Press Push Button 1 for App Image\n");
  #endif
  
  /*Blinking LED3 while waiting for Button1 to be pushed*/  
  while(edge_capture != 0x1)
  {
    IOWR(LED_BASE, 0x0, 0x2);
    usleep(100000);
    IOWR(LED_BASE, 0x0, 0x3);
    usleep(100000);
  }
  
  #if USE_JTAG_UART
  alt_putstr("\nButton1 is pressed, configuring to App Image\n");
  alt_putstr("The nios2-terminal will now close. Please open a new one for App Image\n");
    
  /*Close the terminal before reconfiguration*/  
  alt_printf("%c",4);
    
  /*Delay 100ms for closing terminal*/   
  usleep(100000); 
  #endif
        
  /*Reconfiguration settings*/
  /*Make sure flash is in Read mode*/
  IOWR_8DIRECT( CFI_FLASH_BASE, 0, 0xFF );

  /*Disable Remote Update Controller's watchdog timer*/
  IOWR( REMOTE_UPDATE_BASE, 0x3, 0  );
  
  /*Write the offset of the hardware image in flash*/
  IOWR( REMOTE_UPDATE_BASE, 0x4, hw_flash_offset >> 3  );
                   
  //Reconfigure
  IOWR( REMOTE_UPDATE_BASE, 0x20, 0x1 );  

  return 0;
}
