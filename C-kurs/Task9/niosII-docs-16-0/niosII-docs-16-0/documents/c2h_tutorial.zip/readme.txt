*****************************************************************
*  Accelerating Nios II Systems with the C2H Compiler Tutorial  *
*****************************************************************


Reference:
=========

Please refer to the Accelerating Nios II Systems with the C2H Compiler Tutorial for instructions
on how to use these designs files.  The design shows an example of implementing a radix 2 FFT
in software as well as a hardware accelerated version using the Nios II C2H Compiler.




Hardware and Software Requirements:
==================================

This tutorial requires you to have the following software and hardware:

o Quartus II development software version 7.2 or later, installed on a Windows or Linux computer
o Nios II Embedded Design Suite (EDS) version 7.2 or later
o One of the following Nios II development boards:
    o Stratix II Edition
    o Cyclone II Edition
o A JTAG download cable compatible with your target hardware, such as a USB-Blaster cable.





Expected Results (Cyclone II):
=============================

FFT Benchmark Starting (this will take up to 20 seconds)
- Running 1000 iterations for both software and hardware.
- Each iteration runs a 256 point radix 2 FFT transformation.

--Performance Counter Report--
Total Time: 7.75425 seconds  (1033899812 clock-cycles)
+---------------+-----+-----------+---------------+-----------+
| Section       |  %  | Time (sec)|  Time (clocks)|Occurrences|
+---------------+-----+-----------+---------------+-----------+
|Software Only  | 99.5|    7.71369|     1028492626|          1|
+---------------+-----+-----------+---------------+-----------+
|HW Accelerated |0.512|    0.03968|        5290259|          1|
+---------------+-----+-----------+---------------+-----------+

The software only output data is correct
The hardware accelerated output data is correct 

nios2-terminal: exiting due to ^D on remote




Contacting Altera
=================

Although we have made every effort to ensure that this version of the tutorial
works correctly, there may be problems that we have  not encountered. If you
have a question or problem that is not answered by the information provided in
this readme file, please contact your Altera Field Applications Engineer.

If you have additional questions that are not answered in the documentation
provided with this design, contact Altera Applications using one of the
following methods:

Technical Support Hotline:  (800) 800-EPLD (U.S.)
                            (408) 544-7000 (Internationally)
World wide web:             http://www.altera.com/mysupport

Last updated August, 2007
Copyright � 2007 Altera Corporation. All rights reserved.
