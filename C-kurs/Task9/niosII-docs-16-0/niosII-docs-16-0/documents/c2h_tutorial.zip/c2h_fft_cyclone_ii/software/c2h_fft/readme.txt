This template is starting point for creating a project based on your custom C code.
It will provide you a default project to which you can add your software files. To
add files to a project, manually copy the file into the application directory (e.g. 
using Windows Explorer), then right click on your application project and select 
refresh.

You can also add files to the project using the Nios II IDE import function. 
Select File -> Import. 
Select File System in the Import Window and click Next.
Browse to the appropriate directory containing the files to be added and click OK.
Check the files you want to add and click Finish.
