#ifndef _ACCELERATOR_OPTIMIZED_FFT_H_
#define _ACCELERATOR_OPTIMIZED_FFT_H_

#include "pound_defines.h"
#include "alt_types.h"

                      
void accelerator_optimized_fft(alt_16 * __restrict__ InData,
                        alt_16 * __restrict__ OutData);
                     

/* These pragmas below are pointers to be bound to a specific memory
 * in order to reduce the arbitration (instead of connecting the master to
 * everything */
#pragma altera_accelerate connect_variable accelerator_optimized_fft/tempInputPtr to sdram arbitration_share 100
#pragma altera_accelerate connect_variable accelerator_optimized_fft/tempCosinePtr to sdram arbitration_share 100
#pragma altera_accelerate connect_variable accelerator_optimized_fft/tempOutputPtr to sdram arbitration_share 100
#pragma altera_accelerate connect_variable accelerator_optimized_fft/slaveSelection to sdram

#pragma altera_accelerate connect_variable accelerator_optimized_fft/BufferedRealCalcDataRead to BufferRAM1/s1
#pragma altera_accelerate connect_variable accelerator_optimized_fft/BufferedRealCalcDataRead to BufferRAM2/s1

#pragma altera_accelerate connect_variable accelerator_optimized_fft/BufferedRealCalcDataWrite to BufferRAM1/s1
#pragma altera_accelerate connect_variable accelerator_optimized_fft/BufferedRealCalcDataWrite to BufferRAM2/s1

/* Real input data rotations buffers port 2 */
#pragma altera_accelerate connect_variable accelerator_optimized_fft/BufferedRealCalcDataReadPort2 to BufferRAM1/s2
#pragma altera_accelerate connect_variable accelerator_optimized_fft/BufferedRealCalcDataReadPort2 to BufferRAM2/s2

#pragma altera_accelerate connect_variable accelerator_optimized_fft/BufferedRealCalcDataWritePort2 to BufferRAM1/s2
#pragma altera_accelerate connect_variable accelerator_optimized_fft/BufferedRealCalcDataWritePort2 to BufferRAM2/s2

#pragma altera_accelerate connect_variable accelerator_optimized_fft/BufferedImagCalcDataRead to BufferRAM3/s1
#pragma altera_accelerate connect_variable accelerator_optimized_fft/BufferedImagCalcDataRead to BufferRAM4/s1

#pragma altera_accelerate connect_variable accelerator_optimized_fft/BufferedImagCalcDataWrite to BufferRAM3/s1
#pragma altera_accelerate connect_variable accelerator_optimized_fft/BufferedImagCalcDataWrite to BufferRAM4/s1

/* Imaginary input data rotation buffers port 2 */
#pragma altera_accelerate connect_variable accelerator_optimized_fft/BufferedImagCalcDataReadPort2 to BufferRAM3/s2
#pragma altera_accelerate connect_variable accelerator_optimized_fft/BufferedImagCalcDataReadPort2 to BufferRAM4/s2

#pragma altera_accelerate connect_variable accelerator_optimized_fft/BufferedImagCalcDataWritePort2 to BufferRAM3/s2
#pragma altera_accelerate connect_variable accelerator_optimized_fft/BufferedImagCalcDataWritePort2 to BufferRAM4/s2

#pragma altera_accelerate connect_variable accelerator_optimized_fft/CosineTable to CosRAM

#pragma altera_accelerate connect_variable accelerator_optimized_fft/SineTable to SinRAM






#endif //_ACCELERATOR_OPTIMIZED_FFT_H_
