#include "altera_avalon_performance_counter.h"
#include "system.h"
#include "stdio.h"
#include "pound_defines.h"
#include "sw_only_fft.h"
#include "accelerator_optimized_fft.h"

int main()
{
  unsigned int iteration_counter, point_counter;
  static short OutputData[NUM_POINTS*2];
  static short AccOutputData[NUM_POINTS*2];
  static short InputData[NUM_POINTS*2];
  
  int software_only_error = 0;
  int accelerator_error = 0;
  
  static  short cosine_buf[] = {
    #include "twiddles.dat"
  }; 
  static short InData[] = {
    #include "testdata.dat"
  }; 
  static short expected_results[] = {
    #include "results.dat"
  };
      
  /* Prescaling inputs, going through NUM_POINTS * 2 since each point
   * has interleaved real and imaginary components */  
  for(point_counter = 0; point_counter < (NUM_POINTS*2); point_counter++)
  {
    InputData[point_counter] = InData[point_counter] >> FFT_SIZE;   
  } 
  
  printf("FFT Benchmark Starting (this will take up to 20 seconds)\n");
  printf("- Running %u iterations for both software and hardware.\n", NUM_ITERATIONS);
  printf("- Each iteration runs a %u point radix 2 FFT transformation.\n\n", NUM_POINTS);      
  PERF_RESET(PERFORMANCE_COUNTER_BASE);
  PERF_START_MEASURING(PERFORMANCE_COUNTER_BASE);
  
  /***************************************************************************/
  /* perform the software only benchmarking 
   * kicks off the first performance counter, and runs through calling the
   * software only version of the fft algorithm  */
  /***************************************************************************/
  PERF_BEGIN (PERFORMANCE_COUNTER_BASE, 1);
  for(iteration_counter = 0; iteration_counter < NUM_ITERATIONS; iteration_counter++)
  {
    software_only_fft(InputData,OutputData,cosine_buf);  
  }
  PERF_END (PERFORMANCE_COUNTER_BASE, 1);
  
  /* Check results */
  for (point_counter = 0;point_counter<NUM_POINTS;point_counter++) {
    if (OutputData[2*point_counter] != expected_results[2*point_counter]) {
      software_only_error = 1;
      printf("Software Only FFT is incorrect\n");
      printf("Error at index %d, received %d %di, expected %d %di\n",
              point_counter,
              OutputData[2*point_counter],
              OutputData[2*point_counter+1],
              expected_results[2*point_counter],
              expected_results[2*point_counter+1]);
    }
    if (OutputData[2*point_counter+1] != expected_results[2*point_counter+1]) {
      software_only_error = 1;
      printf("Software Only FFT is incorrect\n");
      printf("Error at index %d, received %d %di, expected %d %di\n",
              point_counter,
              OutputData[2*point_counter],
              OutputData[2*point_counter+1],
              expected_results[2*point_counter],
              expected_results[2*point_counter+1]);
    }    
  }

  /***************************************************************************/
  /* end of software only benchmarking */
  /***************************************************************************/
  
  
  /***************************************************************************/
  /* perform the hardware accelerated benchmarking by kicking off 
   * the second performance counter, and runs through calling the optimized
   * for acclerated version of the fft algorithm */
  /***************************************************************************/
  PERF_BEGIN (PERFORMANCE_COUNTER_BASE, 2);
  for(iteration_counter = 0; iteration_counter < NUM_ITERATIONS; iteration_counter++)
  {
    accelerator_optimized_fft(InputData,AccOutputData); 
  }
  PERF_END (PERFORMANCE_COUNTER_BASE, 2);
  
  /* Check results */
  for (point_counter = 0;point_counter<NUM_POINTS;point_counter++) {
    if (AccOutputData[2*point_counter] != expected_results[2*point_counter]) {
      accelerator_error = 1;
      printf("Accelerated FFT is incorrect\n");
      printf("Error at index %d, received %d %di, expected %d %di\n",
              point_counter,
              AccOutputData[2*point_counter],
              AccOutputData[2*point_counter+1],
              expected_results[2*point_counter],
              expected_results[2*point_counter+1]);
      break; 
    }
    if (AccOutputData[2*point_counter+1] != expected_results[2*point_counter+1]) {
      accelerator_error = 1;
      printf("Accelerated FFT is incorrect\n");
      printf("Error at index %d, received %d %di, expected %d %di\n",
              point_counter,
              AccOutputData[2*point_counter],
              AccOutputData[2*point_counter+1],
              expected_results[2*point_counter],
              expected_results[2*point_counter+1]);
      break; 
    }    
  }


  /***************************************************************************/
  /* output results                                 */
  /***************************************************************************/  
  PERF_STOP_MEASURING(PERFORMANCE_COUNTER_BASE);  

  perf_print_formatted_report((void *)PERFORMANCE_COUNTER_BASE,
                              ALT_CPU_FREQ,
                              2,
                              "Software Only",
                              "HW Accelerated");

  if(software_only_error == 0) {
    printf("\nThe software only output data is correct\n");
  } 
  
  if(accelerator_error == 0) {
    printf("The hardware accelerated output data is correct %c", 0x4);
  } 
   
  return 1;  /* sure why not */
}
