#ifndef _POUND_DEFINES_H_
#define _POUND_DEFINES_H_


#define NUM_ITERATIONS 1000  
#define NUM_POINTS 256       /* Don't touch (input data size) */
#define FFT_SIZE 8           /* Don't touch, this is log2(NUM_POINTS) */
#define PRESCALE 15 
#define BUTTERFLY_SCALE_FACTOR 15

#define BufferRAM1 (alt_16 *)0x0000
#define BufferRAM2 (alt_16 *)0x0200
#define BufferRAM3 (alt_16 *)0x0400
#define BufferRAM4 (alt_16 *)0x0600
#define CosRAM (alt_16 *)0x0800
#define SinRAM (alt_16 *)0x0A00

/* Here is macro to bit reverse an char */
#define bitrev(b) (((b)<<7)&0x80) |  \
      (((b)<<5)&0x40) |  \
      (((b)<<3)&0x20) |  \
      (((b)<<1)&0x10) |  \
      (((b)>>1)&0x08) |  \
      (((b)>>3)&0x04) |  \
      (((b)>>5)&0x02) |  \
      (((b)>>7)&0x01)


#endif //_POUND_DEFINES_H_
