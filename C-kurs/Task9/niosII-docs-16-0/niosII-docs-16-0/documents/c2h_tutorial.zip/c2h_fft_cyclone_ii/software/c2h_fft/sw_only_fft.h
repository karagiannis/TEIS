#ifndef _SW_ONLY_FFT_H_
#define _SW_ONLY_FFT_H_

#include "pound_defines.h"
#include <alt_types.h>

void software_only_fft(alt_16 *InData, alt_16 *OutData, alt_16 *TwiddleTable);
void software_only_fft2(alt_16 *InData, alt_16 *OutData, alt_16 *TwiddleTable);

#endif //_SW_ONLY_FFT_H_
