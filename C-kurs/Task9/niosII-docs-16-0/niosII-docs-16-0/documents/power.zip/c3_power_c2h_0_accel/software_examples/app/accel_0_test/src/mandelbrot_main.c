#include <stdio.h>
#include "alt_types.h"
#include "system.h"
#include "sys/alt_alarm.h"
#include <sys/alt_cache.h>
#include <sys/alt_cache.h>
#include <sys/alt_irq.h>

#include "mandelbrot.h"
#include "reconfig_pll.h"

#define PIX_MAP_WIDTH   (180)
#define PIX_MAP_HEIGHT  (180)

static alt_u8 the_main_frame_buffer[PIX_MAP_WIDTH * PIX_MAP_HEIGHT];
static alt_u8 *main_frame_buffer = the_main_frame_buffer;

volatile MANDELBROT_DESCRIPTOR hw_desc __attribute__((section(".onchip_mem_1KB")));

int int_mandelbrot(long long cr, long long ci, int max_iter);
void draw_int_mandelbrot(float in_x, float in_y, float in_x_dim, int in_max_iter);
void draw_hw_1_int_mandelbrot(float in_x, float in_y, float in_x_dim, int in_max_iter);
void draw_wip_hw_int_mandelbrot(float in_x, float in_y, float in_x_dim, int in_max_iter);

void wip_hw_process_image(MANDELBROT_DESCRIPTOR *hw_desc, alt_u16 mutex_id);

void mandelbrot_main(void)
{
    int i;
    int start_time, end_time, time_taken;
    
    float center_x = -0.5;
    float center_y = 0.0;
    float x_dim = 3.0;
    int max_iter = 255;
    alt_irq_context irq_context;

    alt_u32 cpu_freq[4] = { C4_REG_VALUE_80, C4_REG_VALUE_40, C4_REG_VALUE_20, C4_REG_VALUE_01 };
    char *cpu_freq_strings[4] = { "80MHz", "40MHz", "20MHz", "1MHz" };
    int cpu_freq_iter;
        
            
// draw a frame with the golden software algorithm
    start_time = alt_nticks();
    draw_int_mandelbrot(center_x, center_y, x_dim, max_iter);
    end_time = alt_nticks();
    time_taken = ( end_time - start_time ) / alt_ticks_per_second();
    printf("draw_int_mandelbrot took %lu seconds...\n", time_taken);
    
// draw a frame with the hardware prototype algorithm
    for(i = 0 ; i < (ONCHIP_MEM_32KB_SPAN / 4) ; i++)
    {
        ((alt_u32 *)(ONCHIP_MEM_32KB_BASE))[i] = 0xFFFFFFFF;
    }
    
    alt_dcache_flush_all();
    start_time = alt_nticks();
    draw_wip_hw_int_mandelbrot(center_x, center_y, x_dim, max_iter);
    end_time = alt_nticks();
    time_taken = ( end_time - start_time ) / alt_ticks_per_second();
    printf("draw_wip_hw_int_mandelbrot took %lu seconds...\n", time_taken);

    for(i = 0 ; i < (PIX_MAP_HEIGHT * PIX_MAP_WIDTH) ; i++)
    {
        if(main_frame_buffer[i] != ((volatile alt_u8 *)(ONCHIP_MEM_32KB_BASE | 0x80000000))[i])
        {
            printf("Error at location %d...\n", i);
            printf(" expected 0x%02X\n", main_frame_buffer[i]);
            printf("cache got 0x%02X\n", ((alt_u8 *)(ONCHIP_MEM_32KB_BASE))[i]);
            printf("  ram got 0x%02X\n", ((alt_u8 *)(ONCHIP_MEM_32KB_BASE | 0x80000000))[i]);
            return;
        }
    }
    
    printf("looping in draw_wip_hw_int_mandelbrot\n\n");
    reconfig_pll_init();
    while(1)
    {
        for( cpu_freq_iter = 0 ; cpu_freq_iter < 4 ; cpu_freq_iter++ )
        {
            reconfig_pll_set_cpu_freq(cpu_freq[cpu_freq_iter]);
            reconfig_pll_update_config_pll();

            printf("PLL configuration - CPU @ %s\n", cpu_freq_strings[cpu_freq_iter]);

            usleep(1000000);
            start_time = alt_nticks();
            draw_wip_hw_int_mandelbrot(center_x, center_y, x_dim, max_iter);
            end_time = alt_nticks();
            time_taken = ( end_time - start_time ) / alt_ticks_per_second();

            printf("Computed 1 frame in %d seconds at %s...\n\n", time_taken, cpu_freq_strings[cpu_freq_iter]);
        }
    }
}

// this routine calculates the mandelbrot algorithm with integer math
int int_mandelbrot(long long cr, long long ci, int max_iter)
{
  long long xsqr=0x0, ysqr=0x0, x=0x0, y=0x0;
  long iter=0;
  
  // go ahead and shift these up to the new decimal offset
  ci = ci<<28;
  cr = cr<<28;
  
  while( ((xsqr + ysqr) < 0x0400000000000000LL) && (iter < max_iter) )
  {
    xsqr = (x * x);
    ysqr = (y * y);
    y = (2 * x * y) + ci;
    x = xsqr - ysqr + cr;

    //xsqr should always be positive
    //ysqr should always be positive

    //x = x  / 0x10000000;
    //x may be positive or negative so handle the sign
    if( x & 0x8000000000000000LL )
    {
      x = x >> 28;
      x |= 0xfffffff000000000LL;
    }
    else
    {
      x = x >> 28;
    }
    
    //y = y  / 0x10000000;
    //y may be positive or negative so handle the sign
    if( y & 0x8000000000000000LL )
    {
      y = y >> 28;
      y |= 0xfffffff000000000LL;
    }
    else
    {
      y = y >> 28;
    }
    iter++;
  }
  return(iter);
}

// this routine is the loop overhead for the integer mandelbrot algorithm
void draw_int_mandelbrot(float in_x, float in_y, float in_x_dim, int in_max_iter)
{
  int max_iter, iters, i, j;
  long long leftmost_x, current_x, current_y, x_dim, center_x, center_y, step_dim;
  unsigned char *uncached_buffer;
  
  // make the frame buffer pointer uncached
  uncached_buffer = (unsigned char *)(alt_remap_uncached( (void *)(main_frame_buffer), (alt_u32)(PIX_MAP_WIDTH * PIX_MAP_HEIGHT)));
                
  // set the initial center point, x dimension, and maximum iterations
  center_x = (long long)(in_x * 0x10000000);
  center_y = (long long)(in_y * 0x10000000);
  x_dim = (long long)(in_x_dim * 0x10000000);
  max_iter = in_max_iter;

  // calculate the step dimension between each pixel
  step_dim = x_dim / PIX_MAP_WIDTH;
  
  // calculate the top left pixel value to start with
  current_x = center_x - (x_dim / 2);
  leftmost_x = current_x;
  current_y = center_y + ((PIX_MAP_HEIGHT / 2) * step_dim);
  
  //process the image
  for(i=0; i<PIX_MAP_HEIGHT ; i++)  // i counts the rows in the image
  {
    for(j=0; j<PIX_MAP_WIDTH; j++)  // j counts the columns in the row
    {
      iters = int_mandelbrot(current_x, current_y, max_iter);    // evaluate this coordinate
      *(uncached_buffer + (i*PIX_MAP_WIDTH) + j) = iters;
      current_x += step_dim;    // increment coordinate to next column
    }
    current_x = leftmost_x;     // reset coordinate to first column of image
    current_y -= step_dim;      // increment coordinate to next row in image
  }
}

void draw_wip_hw_int_mandelbrot(float in_x, float in_y, float in_x_dim, int in_max_iter)
{
  alt_u8 max_iter; 
  long long leftmost_x, current_x, current_y, x_dim;
  long center_x, center_y, step_dim;
  unsigned char *uncached_buffer;
  
  // make the frame buffer pointer uncached
  uncached_buffer = (unsigned char *)(alt_remap_uncached( (void *)(ONCHIP_MEM_32KB_BASE), (alt_u32)(PIX_MAP_WIDTH * PIX_MAP_HEIGHT)));
                
  // set the initial center point, x dimension, and maximum iterations
  center_x = (long long)(in_x * 0x10000000);
  center_y = (long long)(in_y * 0x10000000);
  x_dim = (long long)(in_x_dim * 0x10000000);
  max_iter = in_max_iter;

  // calculate the step dimension between each pixel
  step_dim = x_dim / PIX_MAP_WIDTH;
  
  // calculate the top left pixel value to start with
  current_x = center_x - (x_dim / 2);
  leftmost_x = current_x;
  current_y = center_y + ((PIX_MAP_HEIGHT / 2) * step_dim);
  
  //process the image
    hw_desc.current_pixel_count = 0;
    hw_desc.x_pixel_count = 0;
    hw_desc.max_pixel_count = PIX_MAP_HEIGHT * PIX_MAP_WIDTH;
    hw_desc.current_x = current_x;
    hw_desc.current_y = current_y;
    hw_desc.leftmost_x = leftmost_x;
    hw_desc.step_dim = step_dim;
    hw_desc.output_buffer_base = uncached_buffer;
    hw_desc.pix_map_height  = PIX_MAP_HEIGHT;
    hw_desc.pix_map_width = PIX_MAP_WIDTH;
    hw_desc.max_iter = max_iter;
    hw_desc.mutex_base = (alt_u32 *)MUTEX_BASE;
    
    wip_hw_process_image(&hw_desc, 100);
}
