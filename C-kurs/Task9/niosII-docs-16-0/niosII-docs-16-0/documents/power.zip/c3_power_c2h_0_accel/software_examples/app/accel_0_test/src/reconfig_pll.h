#ifndef RECONFIG_PLL_H_
#define RECONFIG_PLL_H_

#include "alt_types.h"

#define LFCP_RES_VALUE      (24)
#define LFCP_CAP_VALUE      (0)
#define CHARGE_PUMP_VALUE   (1)
#define LFCP_REG_VALUE ((((LFCP_CAP_VALUE << 8) + LFCP_RES_VALUE) << 9) + CHARGE_PUMP_VALUE)

#define N_HIGH_VALUE    (3)
#define N_LOW_VALUE     (2)
#define N_BYPASS_VALUE  (0)
#define N_ODD_VALUE     (1)
#define N_REG_VALUE ((((N_BYPASS_VALUE << 8) + N_HIGH_VALUE) << 9) + ((N_ODD_VALUE << 8) + N_LOW_VALUE))

#define M_HIGH_VALUE    (0x10)
#define M_LOW_VALUE     (0x10)
#define M_BYPASS_VALUE  (0)
#define M_ODD_VALUE     (0)
#define M_REG_VALUE ((((M_BYPASS_VALUE << 8) + M_HIGH_VALUE) << 9) + ((M_ODD_VALUE << 8) + M_LOW_VALUE))

#define C0_HIGH_VALUE    (0x02)
#define C0_LOW_VALUE     (0x02)
#define C0_BYPASS_VALUE  (0)
#define C0_ODD_VALUE     (0)
#define C0_REG_VALUE_01 ((((C0_BYPASS_VALUE << 8) + (160)) << 9) + ((C0_ODD_VALUE << 8) + (160)))
#define C0_REG_VALUE_20 ((((C0_BYPASS_VALUE << 8) + (C0_HIGH_VALUE << 2)) << 9) + ((C0_ODD_VALUE << 8) + (C0_LOW_VALUE << 2)))
#define C0_REG_VALUE_40 ((((C0_BYPASS_VALUE << 8) + (C0_HIGH_VALUE << 1)) << 9) + ((C0_ODD_VALUE << 8) + (C0_LOW_VALUE << 1)))
#define C0_REG_VALUE_80 ((((C0_BYPASS_VALUE << 8) + (C0_HIGH_VALUE << 0)) << 9) + ((C0_ODD_VALUE << 8) + (C0_LOW_VALUE << 0)))

#define C1_HIGH_VALUE    (0x0F)
#define C1_LOW_VALUE     (0x0F)
#define C1_BYPASS_VALUE  (1)
#define C1_ODD_VALUE     (1)
#define C1_REG_VALUE_01 ((((C1_BYPASS_VALUE << 8) + (160)) << 9) + ((C1_ODD_VALUE << 8) + (160)))
#define C1_REG_VALUE_20 ((((C1_BYPASS_VALUE << 8) + (C1_HIGH_VALUE << 2)) << 9) + ((C1_ODD_VALUE << 8) + (C1_LOW_VALUE << 2)))
#define C1_REG_VALUE_40 ((((C1_BYPASS_VALUE << 8) + (C1_HIGH_VALUE << 1)) << 9) + ((C1_ODD_VALUE << 8) + (C1_LOW_VALUE << 1)))
#define C1_REG_VALUE_80 ((((C1_BYPASS_VALUE << 8) + (C1_HIGH_VALUE << 0)) << 9) + ((C1_ODD_VALUE << 8) + (C1_LOW_VALUE << 0)))

#define C2_HIGH_VALUE    (0x08)
#define C2_LOW_VALUE     (0x08)
#define C2_BYPASS_VALUE  (0)
#define C2_ODD_VALUE     (0)
#define C2_REG_VALUE ((((C2_BYPASS_VALUE << 8) + (C2_HIGH_VALUE << 0)) << 9) + ((C2_ODD_VALUE << 8) + (C2_LOW_VALUE << 0)))

#define C3_HIGH_VALUE    (0x02)
#define C3_LOW_VALUE     (0x02)
#define C3_BYPASS_VALUE  (0)
#define C3_ODD_VALUE     (0)
#define C3_REG_VALUE_01 ((((C3_BYPASS_VALUE << 8) + (160)) << 9) + ((C3_ODD_VALUE << 8) + (160)))
#define C3_REG_VALUE_20 ((((C3_BYPASS_VALUE << 8) + (C3_HIGH_VALUE << 2)) << 9) + ((C3_ODD_VALUE << 8) + (C3_LOW_VALUE << 2)))
#define C3_REG_VALUE_40 ((((C3_BYPASS_VALUE << 8) + (C3_HIGH_VALUE << 1)) << 9) + ((C3_ODD_VALUE << 8) + (C3_LOW_VALUE << 1)))
#define C3_REG_VALUE_80 ((((C3_BYPASS_VALUE << 8) + (C3_HIGH_VALUE << 0)) << 9) + ((C3_ODD_VALUE << 8) + (C3_LOW_VALUE << 0)))

#define C4_HIGH_VALUE    (0x02)
#define C4_LOW_VALUE     (0x02)
#define C4_BYPASS_VALUE  (0)
#define C4_ODD_VALUE     (0)
#define C4_REG_VALUE_01 ((((C4_BYPASS_VALUE << 8) + (160)) << 9) + ((C4_ODD_VALUE << 8) + (160)))
#define C4_REG_VALUE_20 ((((C4_BYPASS_VALUE << 8) + (C4_HIGH_VALUE << 2)) << 9) + ((C4_ODD_VALUE << 8) + (C4_LOW_VALUE << 2)))
#define C4_REG_VALUE_40 ((((C4_BYPASS_VALUE << 8) + (C4_HIGH_VALUE << 1)) << 9) + ((C4_ODD_VALUE << 8) + (C4_LOW_VALUE << 1)))
#define C4_REG_VALUE_80 ((((C4_BYPASS_VALUE << 8) + (C4_HIGH_VALUE << 0)) << 9) + ((C4_ODD_VALUE << 8) + (C4_LOW_VALUE << 0)))

void reconfig_pll_scan_test(void);
void reconfig_pll_init(void);
void reconfig_pll_set_cpu_freq(alt_u32 new_freq);
void reconfig_pll_set_accel_freq(alt_u32 new_freq);
void reconfig_pll_update_config_pll(void);
void reconfig_pll_01(void);
void reconfig_pll_20(void);
void reconfig_pll_40(void);
void reconfig_pll_80(void);

#endif /*RECONFIG_PLL_H_*/
