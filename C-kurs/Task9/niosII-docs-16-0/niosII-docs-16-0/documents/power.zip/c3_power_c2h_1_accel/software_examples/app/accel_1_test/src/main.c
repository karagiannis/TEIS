#include <stdio.h>
#include "altera_avalon_mutex_regs.h"
#include "alt_types.h"
#include "system.h"
#include <sys/alt_cache.h>

extern void mandelbrot_main(void);

int main()
{
    int i;
    alt_u32 random_init = 0x33557799;
    alt_u32 next_random;
    alt_u32 *ram_ptr;
    
    printf("C2H ONE Mandelbrot core test beginning...\n");

    if(IORD_ALTERA_AVALON_MUTEX_MUTEX(MUTEX_BASE) & 0xFFFF)
    {
        printf("Mutex seems to be locked at program start, this is fatal, exiting...\n");
        return(0);
    }
    else
    {
        printf("Mutex is unlocked at program start as expected...\n");
    }

// ram test one    
    alt_dcache_flush_all();
    ram_ptr = (alt_u32 *)ONCHIP_MEM_32KB_BASE;
    next_random = random_init;
    for(i = 0 ; i < (ONCHIP_MEM_32KB_SPAN / 4) ; i++)
    {
        ram_ptr[i] = next_random;
        next_random = ((next_random << 5) | (next_random >> 27)) + random_init; 
    }
    alt_dcache_flush_all();
    
    next_random = random_init;
    for(i = 0 ; i < (ONCHIP_MEM_32KB_SPAN / 4) ; i++)
    {
        if(ram_ptr[i] != next_random)
        {
            printf("ram test one error on pass %d\n", i);
            printf("expected 0x%08X\n", (unsigned int)next_random);
            printf("    read 0x%08X\n", (unsigned int)ram_ptr[i]);
            printf("\n");
            printf("Exiting on first error...\n");
            return(0);
        }
        next_random = ((next_random << 5) | (next_random >> 27)) + random_init; 
    }
    alt_dcache_flush_all();
    printf("ram test one passed...\n");
        
// ram test two    
    alt_dcache_flush_all();
    ram_ptr = (alt_u32 *)ONCHIP_MEM_32KB_BASE;
    random_init = next_random;
    for(i = 0 ; i < (ONCHIP_MEM_32KB_SPAN / 4) ; i++)
    {
        ram_ptr[i] = next_random;
        next_random = ((next_random << 5) | (next_random >> 27)) + random_init; 
    }
    alt_dcache_flush_all();
    
    next_random = random_init;
    for(i = 0 ; i < (ONCHIP_MEM_32KB_SPAN / 4) ; i++)
    {
        if(ram_ptr[i] != next_random)
        {
            printf("ram test two error on pass %d\n", i);
            printf("expected 0x%08X\n", (unsigned int)next_random);
            printf("    read 0x%08X\n", (unsigned int)ram_ptr[i]);
            printf("\n");
            printf("Exiting on first error...\n");
            return(0);
        }
        next_random = ((next_random << 5) | (next_random >> 27)) + random_init; 
    }
    alt_dcache_flush_all();
    printf("ram test two passed...\n");
        
// ram test three
    alt_dcache_flush_all();
    ram_ptr = (alt_u32 *)ONCHIP_MEM_1KB_BASE;
    random_init = next_random;
    for(i = 0 ; i < (ONCHIP_MEM_1KB_SPAN / 4) ; i++)
    {
        ram_ptr[i] = next_random;
        next_random = ((next_random << 5) | (next_random >> 27)) + random_init; 
    }
    alt_dcache_flush_all();
    
    next_random = random_init;
    for(i = 0 ; i < (ONCHIP_MEM_1KB_SPAN / 4) ; i++)
    {
        if(ram_ptr[i] != next_random)
        {
            printf("ram test three error on pass %d\n", i);
            printf("expected 0x%08X\n", (unsigned int)next_random);
            printf("    read 0x%08X\n", (unsigned int)ram_ptr[i]);
            printf("\n");
            printf("Exiting on first error...\n");
            return(0);
        }
        next_random = ((next_random << 5) | (next_random >> 27)) + random_init; 
    }
    alt_dcache_flush_all();
    printf("ram test three passed...\n");

// ram test four
    alt_dcache_flush_all();
    ram_ptr = (alt_u32 *)ONCHIP_MEM_1KB_BASE;
    random_init = next_random;
    for(i = 0 ; i < (ONCHIP_MEM_1KB_SPAN / 4) ; i++)
    {
        ram_ptr[i] = next_random;
        next_random = ((next_random << 5) | (next_random >> 27)) + random_init; 
    }
    alt_dcache_flush_all();
    
    next_random = random_init;
    for(i = 0 ; i < (ONCHIP_MEM_1KB_SPAN / 4) ; i++)
    {
        if(ram_ptr[i] != next_random)
        {
            printf("ram test four error on pass %d\n", i);
            printf("expected 0x%08X\n", (unsigned int)next_random);
            printf("    read 0x%08X\n", (unsigned int)ram_ptr[i]);
            printf("\n");
            printf("Exiting on first error...\n");
            return(0);
        }
        next_random = ((next_random << 5) | (next_random >> 27)) + random_init; 
    }
    alt_dcache_flush_all();
    printf("ram test four passed...\n");

    printf("Calling Mandelbrot Main...\n\n");
    mandelbrot_main();
    
    printf("exiting...\n");
    return 0;
}
