#include "system.h"
#include "io.h"
#include "altera_avalon_pio_regs.h"
#include "stdio.h"
#include "reconfig_pll.h"

void reconfig_pll_init(void)
{
    IOWR_ALTERA_AVALON_PIO_DATA(LFCP_PIO_BASE, LFCP_REG_VALUE);
    IOWR_ALTERA_AVALON_PIO_DATA(N_PIO_BASE, N_REG_VALUE);
    IOWR_ALTERA_AVALON_PIO_DATA(M_PIO_BASE, M_REG_VALUE);
    IOWR_ALTERA_AVALON_PIO_DATA(C0_PIO_BASE, C0_REG_VALUE_80);
    IOWR_ALTERA_AVALON_PIO_DATA(C1_PIO_BASE, C1_REG_VALUE_80);
    IOWR_ALTERA_AVALON_PIO_DATA(C2_PIO_BASE, C2_REG_VALUE_80);
    IOWR_ALTERA_AVALON_PIO_DATA(C3_PIO_BASE, C3_REG_VALUE);
    IOWR_ALTERA_AVALON_PIO_DATA(C4_PIO_BASE, C4_REG_VALUE_80);
}

void reconfig_pll_set_cpu_freq(alt_u32 new_freq)
{
    IOWR_ALTERA_AVALON_PIO_DATA(C1_PIO_BASE, new_freq);
}

void reconfig_pll_set_accel_freq(alt_u32 new_freq)
{
    IOWR_ALTERA_AVALON_PIO_DATA(C4_PIO_BASE, new_freq);
}

void reconfig_pll_update_config_pll(void)
{
    int i;
    
    IOWR_ALTERA_AVALON_PIO_DATA(START_SCAN_PIO_BASE, 0x01);
    IOWR_ALTERA_AVALON_PIO_DATA(START_SCAN_PIO_BASE, 0x00);

    while(IORD_ALTERA_AVALON_PIO_DATA(SCANCLKENA_PIO_BASE));

    IOWR_ALTERA_AVALON_PIO_DATA(UPDATECONFIG_PIO_BASE, 0x01);
    IOWR_ALTERA_AVALON_PIO_DATA(UPDATECONFIG_PIO_BASE, 0x00);

    for(i = 0; i < 100 ; i++)
    {
        if(!(IORD_ALTERA_AVALON_PIO_DATA(SCANDONE_PIO_BASE)))
        {
            return;
        }
    }
    
    IOWR_ALTERA_AVALON_PIO_DATA(ARESET_PIO_BASE, 0x01);
    IOWR_ALTERA_AVALON_PIO_DATA(ARESET_PIO_BASE, 0x00);
    return;
}

