#include "mandelbrot.h"

// unsiged arithmetic version
//unsigned char wip_hw_int_mandelbrot(long in_cr, long in_ci, unsigned char max_iter)
//{
//  unsigned long long uxsqr=0x0, uysqr=0x0;
//  unsigned long  ux=0x0, uy=0x0;
//  unsigned long long  ull_x, ull_y;
//  long iter=0;
//  unsigned long long y_ull;
//  long long y_sll;
//  unsigned char x_neg, y_neg;  
//  
//  // go ahead and shift these up to the new decimal offset
//  long long ci = ((long long)(in_ci))<<28;
//  long long cr = ((long long)(in_cr))<<28;
//  
//  do
//  {
//    x_neg = (ux & 0x80000000) ? (1) : (0);
//    x_neg &= 0x01;
//    ux = (ux & 0x80000000) ? (0-ux) : (ux);
//    y_neg = (uy & 0x80000000) ? (1) : (0);
//    y_neg &= 0x01;
//    uy = (uy & 0x80000000) ? (0-uy) : (uy);
//    ull_x = ux;
//    ull_y = uy;
//    ull_x &= 0xFFFFFFFFLL;
//    ull_y &= 0xFFFFFFFFLL;
//    uxsqr = ull_x * ull_x;
//    uysqr = ull_y * ull_y;
//
//    y_ull = ull_x * ull_y;
//    y_sll = (x_neg ^ y_neg) ? (0 - y_ull) : (y_ull);
//    uy = (((2 * y_sll) + ci) >> 28);
//    ux = (((long long)uxsqr - (long long)uysqr + cr) >> 28);
//    
//    iter++;
//  } while( (((uxsqr + uysqr) >> 56) < 0x04) && (iter < max_iter) );
//  
//  return(iter);
//}

alt_u8 wip_hw_int_mandelbrot(long in_cr, long in_ci, alt_u8 max_iter)
{
  long long xsqr=0x0, ysqr=0x0;
  long  x=0x0, y=0x0;
  long iter=0;
  
  // go ahead and shift these up to the new decimal offset
  long long ci = ((long long)(in_ci))<<28;
  long long cr = ((long long)(in_cr))<<28;
  
  do
  {
    xsqr = ((long long)x * (long long)x);
    ysqr = ((long long)y * (long long)y);
    y = ((2 * (long long)x * (long long)y) + ci) >> 28;
    x = (xsqr - ysqr + cr) >> 28;

    iter++;
  } while( (((xsqr + ysqr) >> 56) < 0x04) && (iter < max_iter) );
  
  return(iter);
}

void wip_hw_lock_mutex(volatile alt_u32 * __restrict__ mutex_base, alt_u16 mutex_id)
{
    do
    {
        *mutex_base = (mutex_id << 16) | mutex_id;
    }while((*mutex_base >> 16) != mutex_id);
}

void wip_hw_unlock_mutex(volatile alt_u32 * __restrict__ mutex_base, alt_u16 mutex_id)
{
    *mutex_base = (mutex_id << 16);
}

void wip_hw_process_image(MANDELBROT_DESCRIPTOR * __restrict__ hw_desc, alt_u16 mutex_id)
{
    alt_u32 max_pixel_count;
    long leftmost_x;
    long step_dim;
    volatile alt_u8 * __restrict__ output_buffer_base;
    short pix_map_width;
    alt_u8 max_iter;
    volatile alt_u32 * __restrict__ mutex_base;
    int i;

    alt_u8 iters;
    
    alt_u32 current_pixel_count;
    long current_x;
    long current_y;

    max_pixel_count = hw_desc->max_pixel_count;
    leftmost_x = hw_desc->leftmost_x;
    step_dim = hw_desc->step_dim;
    output_buffer_base = hw_desc->output_buffer_base;
    pix_map_width = hw_desc->pix_map_width;
    max_iter = hw_desc->max_iter;
    mutex_base = hw_desc->mutex_base;

// lock mutex
    wip_hw_lock_mutex(mutex_base, mutex_id);

    current_pixel_count = hw_desc->current_pixel_count;
    if(current_pixel_count < max_pixel_count)
    {
        do
        {
            hw_desc->current_pixel_count = current_pixel_count + pix_map_width;
            
            current_x = hw_desc->current_x;
            current_y = hw_desc->current_y;
            
            hw_desc->current_y = current_y - step_dim;  // increment coordinate to next row in image
// unlock mutex
            wip_hw_unlock_mutex(mutex_base, mutex_id);
            
            i = 0;
            do
            {
                iters = wip_hw_int_mandelbrot(current_x, current_y, max_iter);    // evaluate this coordinate
                *(output_buffer_base + current_pixel_count) = iters;
                current_x = current_x + step_dim;
                current_pixel_count++;
                i++;
            } while(i < pix_map_width);
    
// lock mutex
            wip_hw_lock_mutex(mutex_base, mutex_id);

            current_pixel_count = hw_desc->current_pixel_count;
        } while(current_pixel_count < max_pixel_count);
    }
// unlock mutex
    wip_hw_unlock_mutex(mutex_base, mutex_id);
}
