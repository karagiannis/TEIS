#include "io.h"

__inline__ void init_c2h_hw_process_image    (
                                        void *c2h_base, 
                                        volatile void *hw_desc,
                                        unsigned short mutex_id
                                    )
{
  /* Poll. When read from address 0 returns 1, the accelerator is done */
  while(IORD_32DIRECT(c2h_base,(0 * sizeof(int))) == 0)
  {}
  IOWR_32DIRECT(c2h_base, (4), (int) (hw_desc));
  IOWR_32DIRECT(c2h_base, (8), (int) (mutex_id));
}

__inline__ void start_c2h_hw_process_image    (
                                        void *c2h_base
                                    )
{
  /* Write 1 to address 0 starts the accelerator */
  IOWR_32DIRECT(c2h_base,(0 * sizeof(int)),1);
}

__inline__ alt_u32 poll_c2h_ready_hw_process_image    (
                                        void *c2h_base
                                    )
{
  /* Poll. When read from address 0 returns 1, the accelerator is done */
  return(IORD_32DIRECT(c2h_base,(0 * sizeof(int))));
}

__inline__ void wait_c2h_ready_hw_process_image    (
                                        void *c2h_base
                                    )
{
  /* Poll. When read from address 0 returns 1, the accelerator is done */
  while(IORD_32DIRECT(c2h_base,(0 * sizeof(int))) == 0)
  {}
}
