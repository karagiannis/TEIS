#include <stdio.h>
#include "alt_types.h"
#include "system.h"
#include <sys/alt_timestamp.h>
#include <sys/alt_cache.h>
#include <sys/alt_cache.h>
#include <sys/alt_irq.h>
#include <sys/alt_alarm.h>

#include "mandelbrot.h"
#include "alt_c2h_hw_process_image.h"
#include "reconfig_pll.h"

#define PIX_MAP_WIDTH   (180)
#define PIX_MAP_HEIGHT  (180)

static alt_u8 the_main_frame_buffer[PIX_MAP_WIDTH * PIX_MAP_HEIGHT];
static alt_u8 *main_frame_buffer = the_main_frame_buffer;

volatile MANDELBROT_DESCRIPTOR hw_desc __attribute__((section(".onchip_mem_1KB")));

int int_mandelbrot(long long cr, long long ci, int max_iter);
void draw_int_mandelbrot(float in_x, float in_y, float in_x_dim, int in_max_iter);
void draw_hw_1_int_mandelbrot(float in_x, float in_y, float in_x_dim, int in_max_iter);
void draw_hw_2_int_mandelbrot(float in_x, float in_y, float in_x_dim, int in_max_iter);
void draw_hw_3_int_mandelbrot(float in_x, float in_y, float in_x_dim, int in_max_iter);
void draw_hw_4_int_mandelbrot(float in_x, float in_y, float in_x_dim, int in_max_iter);
void draw_hw_5_int_mandelbrot(float in_x, float in_y, float in_x_dim, int in_max_iter);
void draw_wip_hw_int_mandelbrot(float in_x, float in_y, float in_x_dim, int in_max_iter);

void wip_hw_process_image(MANDELBROT_DESCRIPTOR *hw_desc, alt_u16 mutex_id);

alt_alarm alarm;
volatile alt_u32 my_context;
alt_u32 my_alarm_callback (void* context)
{
    *((alt_u32 *)(context)) = 1;
    return(0);
}

void mandelbrot_main(void)
{
    int i;
    alt_u32 time_stamp_count;
    
    float center_x = -0.5;
    float center_y = 0.0;
    float x_dim = 3.0;
    int max_iter = 255;
    alt_irq_context context;

    alt_u32 cpu_freq[4] = { C4_REG_VALUE_80, C4_REG_VALUE_40, C4_REG_VALUE_20, C4_REG_VALUE_01 };
    alt_u32 accel_freq[4] = { C1_REG_VALUE_80, C1_REG_VALUE_40, C1_REG_VALUE_20, C1_REG_VALUE_01 };
    char *cpu_freq_strings[4] = { "80MHz", "40MHz", "20MHz", "1MHz" };
    char *accel_freq_strings[4] = { "80MHz", "40MHz", "20MHz", "1MHz" };
    int cpu_freq_iter;
    int accel_freq_iter;
        
// draw a frame with the golden software algorithm
    alt_timestamp_start();
    draw_int_mandelbrot(center_x, center_y, x_dim, max_iter);
    time_stamp_count = alt_timestamp();
    printf("draw_int_mandelbrot took %lu clocks...\n", time_stamp_count);
    
// draw a frame with the hardware prototype algorithm
    for(i = 0 ; i < (ONCHIP_MEM_32KB_SPAN / 4) ; i++)
    {
        ((alt_u32 *)(ONCHIP_MEM_32KB_BASE))[i] = 0xFFFFFFFF;
    }
    
    alt_dcache_flush_all();
    alt_timestamp_start();
    draw_wip_hw_int_mandelbrot(center_x, center_y, x_dim, max_iter);
    time_stamp_count = alt_timestamp();
    printf("draw_wip_hw_int_mandelbrot took %lu clocks...\n", time_stamp_count);

    for(i = 0 ; i < (PIX_MAP_HEIGHT * PIX_MAP_WIDTH) ; i++)
    {
        if(main_frame_buffer[i] != ((volatile alt_u8 *)(ONCHIP_MEM_32KB_BASE | 0x80000000))[i])
        {
            printf("Error at location %d...\n", i);
            printf(" expected 0x%02X\n", main_frame_buffer[i]);
            printf("cache got 0x%02X\n", ((alt_u8 *)(ONCHIP_MEM_32KB_BASE))[i]);
            printf("  ram got 0x%02X\n", ((alt_u8 *)(ONCHIP_MEM_32KB_BASE | 0x80000000))[i]);
            return;
        }
    }
    
// draw a frame with the hardware 1 instance
    for(i = 0 ; i < (ONCHIP_MEM_32KB_SPAN / 4) ; i++)
    {
        ((alt_u32 *)(ONCHIP_MEM_32KB_BASE))[i] = 0x0;
    }

    alt_dcache_flush_all();
    alt_timestamp_start();
    draw_hw_1_int_mandelbrot(center_x, center_y, x_dim, max_iter);
    time_stamp_count = alt_timestamp();
    printf("draw_hw_1_int_mandelbrot took %lu clocks...\n", time_stamp_count);

    for(i = 0 ; i < (PIX_MAP_HEIGHT * PIX_MAP_WIDTH) ; i++)
    {
        if(main_frame_buffer[i] != ((alt_u8 *)(ONCHIP_MEM_32KB_BASE))[i])
        {
            printf("Error at location %d...\n", i);
            printf("expected 0x%02X\n", main_frame_buffer[i]);
            printf("     got 0x%02X\n", ((alt_u8 *)(ONCHIP_MEM_32KB_BASE))[i]);
            return;
        }
    }

// draw a frame with the hardware 2 instances
    for(i = 0 ; i < (ONCHIP_MEM_32KB_SPAN / 4) ; i++)
    {
        ((alt_u32 *)(ONCHIP_MEM_32KB_BASE))[i] = 0x0;
    }

    alt_dcache_flush_all();
    alt_timestamp_start();
    draw_hw_2_int_mandelbrot(center_x, center_y, x_dim, max_iter);
    time_stamp_count = alt_timestamp();
    printf("draw_hw_2_int_mandelbrot took %lu clocks...\n", time_stamp_count);

    for(i = 0 ; i < (PIX_MAP_HEIGHT * PIX_MAP_WIDTH) ; i++)
    {
        if(main_frame_buffer[i] != ((alt_u8 *)(ONCHIP_MEM_32KB_BASE))[i])
        {
            printf("Error at location %d...\n", i);
            printf("expected 0x%02X\n", main_frame_buffer[i]);
            printf("     got 0x%02X\n", ((alt_u8 *)(ONCHIP_MEM_32KB_BASE))[i]);
            return;
        }
    }

// draw a frame with the hardware 3 instances
    for(i = 0 ; i < (ONCHIP_MEM_32KB_SPAN / 4) ; i++)
    {
        ((alt_u32 *)(ONCHIP_MEM_32KB_BASE))[i] = 0x0;
    }

    alt_dcache_flush_all();
    alt_timestamp_start();
    draw_hw_3_int_mandelbrot(center_x, center_y, x_dim, max_iter);
    time_stamp_count = alt_timestamp();
    printf("draw_hw_3_int_mandelbrot took %lu clocks...\n", time_stamp_count);

    for(i = 0 ; i < (PIX_MAP_HEIGHT * PIX_MAP_WIDTH) ; i++)
    {
        if(main_frame_buffer[i] != ((alt_u8 *)(ONCHIP_MEM_32KB_BASE))[i])
        {
            printf("Error at location %d...\n", i);
            printf("expected 0x%02X\n", main_frame_buffer[i]);
            printf("     got 0x%02X\n", ((alt_u8 *)(ONCHIP_MEM_32KB_BASE))[i]);
            return;
        }
    }

// draw a frame with the hardware 4 instances
    for(i = 0 ; i < (ONCHIP_MEM_32KB_SPAN / 4) ; i++)
    {
        ((alt_u32 *)(ONCHIP_MEM_32KB_BASE))[i] = 0x0;
    }

    alt_dcache_flush_all();
    alt_timestamp_start();
    draw_hw_4_int_mandelbrot(center_x, center_y, x_dim, max_iter);
    time_stamp_count = alt_timestamp();
    printf("draw_hw_4_int_mandelbrot took %lu clocks...\n", time_stamp_count);

    for(i = 0 ; i < (PIX_MAP_HEIGHT * PIX_MAP_WIDTH) ; i++)
    {
        if(main_frame_buffer[i] != ((alt_u8 *)(ONCHIP_MEM_32KB_BASE))[i])
        {
            printf("Error at location %d...\n", i);
            printf("expected 0x%02X\n", main_frame_buffer[i]);
            printf("     got 0x%02X\n", ((alt_u8 *)(ONCHIP_MEM_32KB_BASE))[i]);
            return;
        }
    }

// draw a frame with the hardware 5 instances
    for(i = 0 ; i < (ONCHIP_MEM_32KB_SPAN / 4) ; i++)
    {
        ((alt_u32 *)(ONCHIP_MEM_32KB_BASE))[i] = 0x0;
    }

    alt_dcache_flush_all();
    alt_timestamp_start();
    draw_hw_5_int_mandelbrot(center_x, center_y, x_dim, max_iter);
    time_stamp_count = alt_timestamp();
    printf("draw_hw_5_int_mandelbrot took %lu clocks...\n", time_stamp_count);

    for(i = 0 ; i < (PIX_MAP_HEIGHT * PIX_MAP_WIDTH) ; i++)
    {
        if(main_frame_buffer[i] != ((alt_u8 *)(ONCHIP_MEM_32KB_BASE))[i])
        {
            printf("Error at location %d...\n", i);
            printf("expected 0x%02X\n", main_frame_buffer[i]);
            printf("     got 0x%02X\n", ((alt_u8 *)(ONCHIP_MEM_32KB_BASE))[i]);
            return;
        }
    }

    printf("looping in draw_hw_5_int_mandelbrot\n\n");
    reconfig_pll_init();
    while(1)
    {
        for( cpu_freq_iter = 0 ; cpu_freq_iter < 4 ; cpu_freq_iter++ )
        {
            reconfig_pll_set_cpu_freq(cpu_freq[cpu_freq_iter]);
            for( accel_freq_iter = 0 ; accel_freq_iter < 4 ; accel_freq_iter++ )
            {
                reconfig_pll_set_accel_freq(accel_freq[accel_freq_iter]);
                reconfig_pll_update_config_pll();

                printf("PLL configuration - CPU @ %s -- Accelerators @ %s\n", cpu_freq_strings[cpu_freq_iter], accel_freq_strings[accel_freq_iter]);

                my_context = 0;
                if(
                    alt_alarm_start (
                        &alarm,                         // alt_alarm* alarm,
                        alt_ticks_per_second() * 10,    // alt_u32 nticks,
                        my_alarm_callback,              // alt_u32 (*callback) (void* context),
                        (void *)&my_context             // void* context
                    )
                )
                {
                    printf("Error starting alarm...\n");
                    return;
                }
                i = 0;
                while(!my_context)
                {
                    draw_hw_5_int_mandelbrot(center_x, center_y, x_dim, max_iter);
                    i++;
                }
                printf("Computed %d frames in 10 seconds...\n\n", i);
                
            }
        }
    }
}

// this routine calculates the mandelbrot algorithm with integer math
int int_mandelbrot(long long cr, long long ci, int max_iter)
{
  long long xsqr=0x0, ysqr=0x0, x=0x0, y=0x0;
  long iter=0;
  
  // go ahead and shift these up to the new decimal offset
  ci = ci<<28;
  cr = cr<<28;
  
  while( ((xsqr + ysqr) < 0x0400000000000000LL) && (iter < max_iter) )
  {
    xsqr = (x * x);
    ysqr = (y * y);
    y = (2 * x * y) + ci;
    x = xsqr - ysqr + cr;

    //xsqr should always be positive
    //ysqr should always be positive

    //x = x  / 0x10000000;
    //x may be positive or negative so handle the sign
    if( x & 0x8000000000000000LL )
    {
      x = x >> 28;
      x |= 0xfffffff000000000LL;
    }
    else
    {
      x = x >> 28;
    }
    
    //y = y  / 0x10000000;
    //y may be positive or negative so handle the sign
    if( y & 0x8000000000000000LL )
    {
      y = y >> 28;
      y |= 0xfffffff000000000LL;
    }
    else
    {
      y = y >> 28;
    }
    iter++;
  }
  return(iter);
}

// this routine is the loop overhead for the integer mandelbrot algorithm
void draw_int_mandelbrot(float in_x, float in_y, float in_x_dim, int in_max_iter)
{
  int max_iter, iters, i, j;
  long long leftmost_x, current_x, current_y, x_dim, center_x, center_y, step_dim;
  unsigned char *uncached_buffer;
  
  // make the frame buffer pointer uncached
  uncached_buffer = (unsigned char *)(alt_remap_uncached( (void *)(main_frame_buffer), (alt_u32)(PIX_MAP_WIDTH * PIX_MAP_HEIGHT)));
                
  // set the initial center point, x dimension, and maximum iterations
  center_x = (long long)(in_x * 0x10000000);
  center_y = (long long)(in_y * 0x10000000);
  x_dim = (long long)(in_x_dim * 0x10000000);
  max_iter = in_max_iter;

  // calculate the step dimension between each pixel
  step_dim = x_dim / PIX_MAP_WIDTH;
  
  // calculate the top left pixel value to start with
  current_x = center_x - (x_dim / 2);
  leftmost_x = current_x;
  current_y = center_y + ((PIX_MAP_HEIGHT / 2) * step_dim);
  
  //process the image
  for(i=0; i<PIX_MAP_HEIGHT ; i++)  // i counts the rows in the image
  {
    for(j=0; j<PIX_MAP_WIDTH; j++)  // j counts the columns in the row
    {
      iters = int_mandelbrot(current_x, current_y, max_iter);    // evaluate this coordinate
      *(uncached_buffer + (i*PIX_MAP_WIDTH) + j) = iters;
      current_x += step_dim;    // increment coordinate to next column
    }
    current_x = leftmost_x;     // reset coordinate to first column of image
    current_y -= step_dim;      // increment coordinate to next row in image
  }
}

void draw_wip_hw_int_mandelbrot(float in_x, float in_y, float in_x_dim, int in_max_iter)
{
  alt_u8 max_iter; 
  long long leftmost_x, current_x, current_y, x_dim;
  long center_x, center_y, step_dim;
  unsigned char *uncached_buffer;
  
  // make the frame buffer pointer uncached
  uncached_buffer = (unsigned char *)(alt_remap_uncached( (void *)(ONCHIP_MEM_32KB_BASE), (alt_u32)(PIX_MAP_WIDTH * PIX_MAP_HEIGHT)));
                
  // set the initial center point, x dimension, and maximum iterations
  center_x = (long long)(in_x * 0x10000000);
  center_y = (long long)(in_y * 0x10000000);
  x_dim = (long long)(in_x_dim * 0x10000000);
  max_iter = in_max_iter;

  // calculate the step dimension between each pixel
  step_dim = x_dim / PIX_MAP_WIDTH;
  
  // calculate the top left pixel value to start with
  current_x = center_x - (x_dim / 2);
  leftmost_x = current_x;
  current_y = center_y + ((PIX_MAP_HEIGHT / 2) * step_dim);
  
  //process the image
    hw_desc.current_pixel_count = 0;
    hw_desc.x_pixel_count = 0;
    hw_desc.max_pixel_count = PIX_MAP_HEIGHT * PIX_MAP_WIDTH;
    hw_desc.current_x = current_x;
    hw_desc.current_y = current_y;
    hw_desc.leftmost_x = leftmost_x;
    hw_desc.step_dim = step_dim;
    hw_desc.output_buffer_base = uncached_buffer;
    hw_desc.pix_map_height  = PIX_MAP_HEIGHT;
    hw_desc.pix_map_width = PIX_MAP_WIDTH;
    hw_desc.max_iter = max_iter;
    hw_desc.mutex_base = (alt_u32 *)MUTEX_BASE;
    
    wip_hw_process_image(&hw_desc, 100);
}

void draw_hw_5_int_mandelbrot(float in_x, float in_y, float in_x_dim, int in_max_iter)
{
  alt_u8 max_iter; 
  long long leftmost_x, current_x, current_y, x_dim;
  long center_x, center_y, step_dim;
  unsigned char *uncached_buffer;
  volatile MANDELBROT_DESCRIPTOR *uncached_hw_desc_ptr;
  
  uncached_hw_desc_ptr = (MANDELBROT_DESCRIPTOR *)((alt_u32)(&hw_desc) | 0x80000000);
  
  // make the frame buffer pointer uncached
  uncached_buffer = (unsigned char *)(alt_remap_uncached( (void *)(ONCHIP_MEM_32KB_BASE), (alt_u32)(PIX_MAP_WIDTH * PIX_MAP_HEIGHT)));
                
  // set the initial center point, x dimension, and maximum iterations
  center_x = (long long)(in_x * 0x10000000);
  center_y = (long long)(in_y * 0x10000000);
  x_dim = (long long)(in_x_dim * 0x10000000);
  max_iter = in_max_iter;

  // calculate the step dimension between each pixel
  step_dim = x_dim / PIX_MAP_WIDTH;
  
  // calculate the top left pixel value to start with
  current_x = center_x - (x_dim / 2);
  leftmost_x = current_x;
  current_y = center_y + ((PIX_MAP_HEIGHT / 2) * step_dim);
  
  //process the image
    uncached_hw_desc_ptr->current_pixel_count = 0;
    uncached_hw_desc_ptr->x_pixel_count = 0;
    uncached_hw_desc_ptr->max_pixel_count = PIX_MAP_HEIGHT * PIX_MAP_WIDTH;
    uncached_hw_desc_ptr->current_x = current_x;
    uncached_hw_desc_ptr->current_y = current_y;
    uncached_hw_desc_ptr->leftmost_x = leftmost_x;
    uncached_hw_desc_ptr->step_dim = step_dim;
    uncached_hw_desc_ptr->output_buffer_base = (uncached_buffer);
    uncached_hw_desc_ptr->pix_map_height  = PIX_MAP_HEIGHT;
    uncached_hw_desc_ptr->pix_map_width = PIX_MAP_WIDTH;
    uncached_hw_desc_ptr->max_iter = max_iter;
    uncached_hw_desc_ptr->mutex_base = (alt_u32 *)MUTEX_BASE;
    
    init_c2h_hw_process_image(C2H_INST_0_BASE,((alt_u32)(&hw_desc)), 200);
    init_c2h_hw_process_image(C2H_INST_1_BASE,((alt_u32)(&hw_desc)), 201);
    init_c2h_hw_process_image(C2H_INST_2_BASE,((alt_u32)(&hw_desc)), 202);
    init_c2h_hw_process_image(C2H_INST_3_BASE,((alt_u32)(&hw_desc)), 203);
    init_c2h_hw_process_image(C2H_INST_4_BASE,((alt_u32)(&hw_desc)), 204);
    start_c2h_hw_process_image(C2H_INST_0_BASE);
    start_c2h_hw_process_image(C2H_INST_1_BASE);
    start_c2h_hw_process_image(C2H_INST_2_BASE);
    start_c2h_hw_process_image(C2H_INST_3_BASE);
    start_c2h_hw_process_image(C2H_INST_4_BASE);
    wait_c2h_ready_hw_process_image(C2H_INST_0_BASE);
    wait_c2h_ready_hw_process_image(C2H_INST_1_BASE);
    wait_c2h_ready_hw_process_image(C2H_INST_2_BASE);
    wait_c2h_ready_hw_process_image(C2H_INST_3_BASE);
    wait_c2h_ready_hw_process_image(C2H_INST_4_BASE);
}

void draw_hw_4_int_mandelbrot(float in_x, float in_y, float in_x_dim, int in_max_iter)
{
  alt_u8 max_iter; 
  long long leftmost_x, current_x, current_y, x_dim;
  long center_x, center_y, step_dim;
  unsigned char *uncached_buffer;
  volatile MANDELBROT_DESCRIPTOR *uncached_hw_desc_ptr;
  
  uncached_hw_desc_ptr = (MANDELBROT_DESCRIPTOR *)((alt_u32)(&hw_desc) | 0x80000000);
  
  // make the frame buffer pointer uncached
  uncached_buffer = (unsigned char *)(alt_remap_uncached( (void *)(ONCHIP_MEM_32KB_BASE), (alt_u32)(PIX_MAP_WIDTH * PIX_MAP_HEIGHT)));
                
  // set the initial center point, x dimension, and maximum iterations
  center_x = (long long)(in_x * 0x10000000);
  center_y = (long long)(in_y * 0x10000000);
  x_dim = (long long)(in_x_dim * 0x10000000);
  max_iter = in_max_iter;

  // calculate the step dimension between each pixel
  step_dim = x_dim / PIX_MAP_WIDTH;
  
  // calculate the top left pixel value to start with
  current_x = center_x - (x_dim / 2);
  leftmost_x = current_x;
  current_y = center_y + ((PIX_MAP_HEIGHT / 2) * step_dim);
  
  //process the image
    uncached_hw_desc_ptr->current_pixel_count = 0;
    uncached_hw_desc_ptr->x_pixel_count = 0;
    uncached_hw_desc_ptr->max_pixel_count = PIX_MAP_HEIGHT * PIX_MAP_WIDTH;
    uncached_hw_desc_ptr->current_x = current_x;
    uncached_hw_desc_ptr->current_y = current_y;
    uncached_hw_desc_ptr->leftmost_x = leftmost_x;
    uncached_hw_desc_ptr->step_dim = step_dim;
    uncached_hw_desc_ptr->output_buffer_base = (uncached_buffer);
    uncached_hw_desc_ptr->pix_map_height  = PIX_MAP_HEIGHT;
    uncached_hw_desc_ptr->pix_map_width = PIX_MAP_WIDTH;
    uncached_hw_desc_ptr->max_iter = max_iter;
    uncached_hw_desc_ptr->mutex_base = (alt_u32)MUTEX_BASE;
    
    init_c2h_hw_process_image(C2H_INST_0_BASE,((alt_u32)(&hw_desc)), 200);
    init_c2h_hw_process_image(C2H_INST_1_BASE,((alt_u32)(&hw_desc)), 201);
    init_c2h_hw_process_image(C2H_INST_2_BASE,((alt_u32)(&hw_desc)), 202);
    init_c2h_hw_process_image(C2H_INST_3_BASE,((alt_u32)(&hw_desc)), 203);
    start_c2h_hw_process_image(C2H_INST_0_BASE);
    start_c2h_hw_process_image(C2H_INST_1_BASE);
    start_c2h_hw_process_image(C2H_INST_2_BASE);
    start_c2h_hw_process_image(C2H_INST_3_BASE);
    wait_c2h_ready_hw_process_image(C2H_INST_0_BASE);
    wait_c2h_ready_hw_process_image(C2H_INST_1_BASE);
    wait_c2h_ready_hw_process_image(C2H_INST_2_BASE);
    wait_c2h_ready_hw_process_image(C2H_INST_3_BASE);
}

void draw_hw_3_int_mandelbrot(float in_x, float in_y, float in_x_dim, int in_max_iter)
{
  alt_u8 max_iter; 
  long long leftmost_x, current_x, current_y, x_dim;
  long center_x, center_y, step_dim;
  unsigned char *uncached_buffer;
  volatile MANDELBROT_DESCRIPTOR *uncached_hw_desc_ptr;
  
  uncached_hw_desc_ptr = (MANDELBROT_DESCRIPTOR *)((alt_u32)(&hw_desc) | 0x80000000);
  
  // make the frame buffer pointer uncached
  uncached_buffer = (unsigned char *)(alt_remap_uncached( (void *)(ONCHIP_MEM_32KB_BASE), (alt_u32)(PIX_MAP_WIDTH * PIX_MAP_HEIGHT)));
                
  // set the initial center point, x dimension, and maximum iterations
  center_x = (long long)(in_x * 0x10000000);
  center_y = (long long)(in_y * 0x10000000);
  x_dim = (long long)(in_x_dim * 0x10000000);
  max_iter = in_max_iter;

  // calculate the step dimension between each pixel
  step_dim = x_dim / PIX_MAP_WIDTH;
  
  // calculate the top left pixel value to start with
  current_x = center_x - (x_dim / 2);
  leftmost_x = current_x;
  current_y = center_y + ((PIX_MAP_HEIGHT / 2) * step_dim);
  
  //process the image
    uncached_hw_desc_ptr->current_pixel_count = 0;
    uncached_hw_desc_ptr->x_pixel_count = 0;
    uncached_hw_desc_ptr->max_pixel_count = PIX_MAP_HEIGHT * PIX_MAP_WIDTH;
    uncached_hw_desc_ptr->current_x = current_x;
    uncached_hw_desc_ptr->current_y = current_y;
    uncached_hw_desc_ptr->leftmost_x = leftmost_x;
    uncached_hw_desc_ptr->step_dim = step_dim;
    uncached_hw_desc_ptr->output_buffer_base = (uncached_buffer);
    uncached_hw_desc_ptr->pix_map_height  = PIX_MAP_HEIGHT;
    uncached_hw_desc_ptr->pix_map_width = PIX_MAP_WIDTH;
    uncached_hw_desc_ptr->max_iter = max_iter;
    uncached_hw_desc_ptr->mutex_base = (alt_u32)MUTEX_BASE;
    
    init_c2h_hw_process_image(C2H_INST_0_BASE,((alt_u32)(&hw_desc)), 200);
    init_c2h_hw_process_image(C2H_INST_1_BASE,((alt_u32)(&hw_desc)), 201);
    init_c2h_hw_process_image(C2H_INST_2_BASE,((alt_u32)(&hw_desc)), 202);
    start_c2h_hw_process_image(C2H_INST_0_BASE);
    start_c2h_hw_process_image(C2H_INST_1_BASE);
    start_c2h_hw_process_image(C2H_INST_2_BASE);
    wait_c2h_ready_hw_process_image(C2H_INST_0_BASE);
    wait_c2h_ready_hw_process_image(C2H_INST_1_BASE);
    wait_c2h_ready_hw_process_image(C2H_INST_2_BASE);
}

void draw_hw_2_int_mandelbrot(float in_x, float in_y, float in_x_dim, int in_max_iter)
{
  alt_u8 max_iter; 
  long long leftmost_x, current_x, current_y, x_dim;
  long center_x, center_y, step_dim;
  unsigned char *uncached_buffer;
  volatile MANDELBROT_DESCRIPTOR *uncached_hw_desc_ptr;
  
  uncached_hw_desc_ptr = (MANDELBROT_DESCRIPTOR *)((alt_u32)(&hw_desc) | 0x80000000);
  
  // make the frame buffer pointer uncached
  uncached_buffer = (unsigned char *)(alt_remap_uncached( (void *)(ONCHIP_MEM_32KB_BASE), (alt_u32)(PIX_MAP_WIDTH * PIX_MAP_HEIGHT)));
                
  // set the initial center point, x dimension, and maximum iterations
  center_x = (long long)(in_x * 0x10000000);
  center_y = (long long)(in_y * 0x10000000);
  x_dim = (long long)(in_x_dim * 0x10000000);
  max_iter = in_max_iter;

  // calculate the step dimension between each pixel
  step_dim = x_dim / PIX_MAP_WIDTH;
  
  // calculate the top left pixel value to start with
  current_x = center_x - (x_dim / 2);
  leftmost_x = current_x;
  current_y = center_y + ((PIX_MAP_HEIGHT / 2) * step_dim);
  
  //process the image
    uncached_hw_desc_ptr->current_pixel_count = 0;
    uncached_hw_desc_ptr->x_pixel_count = 0;
    uncached_hw_desc_ptr->max_pixel_count = PIX_MAP_HEIGHT * PIX_MAP_WIDTH;
    uncached_hw_desc_ptr->current_x = current_x;
    uncached_hw_desc_ptr->current_y = current_y;
    uncached_hw_desc_ptr->leftmost_x = leftmost_x;
    uncached_hw_desc_ptr->step_dim = step_dim;
    uncached_hw_desc_ptr->output_buffer_base = (uncached_buffer);
    uncached_hw_desc_ptr->pix_map_height  = PIX_MAP_HEIGHT;
    uncached_hw_desc_ptr->pix_map_width = PIX_MAP_WIDTH;
    uncached_hw_desc_ptr->max_iter = max_iter;
    uncached_hw_desc_ptr->mutex_base = (alt_u32)MUTEX_BASE;
    
    init_c2h_hw_process_image(C2H_INST_0_BASE,((alt_u32)(&hw_desc)), 200);
    init_c2h_hw_process_image(C2H_INST_1_BASE,((alt_u32)(&hw_desc)), 201);
    start_c2h_hw_process_image(C2H_INST_0_BASE);
    start_c2h_hw_process_image(C2H_INST_1_BASE);
    wait_c2h_ready_hw_process_image(C2H_INST_0_BASE);
    wait_c2h_ready_hw_process_image(C2H_INST_1_BASE);
}

void draw_hw_1_int_mandelbrot(float in_x, float in_y, float in_x_dim, int in_max_iter)
{
  alt_u8 max_iter; 
  long long leftmost_x, current_x, current_y, x_dim;
  long center_x, center_y, step_dim;
  unsigned char *uncached_buffer;
  volatile MANDELBROT_DESCRIPTOR *uncached_hw_desc_ptr;
  
  uncached_hw_desc_ptr = (MANDELBROT_DESCRIPTOR *)((alt_u32)(&hw_desc) | 0x80000000);
  
  // make the frame buffer pointer uncached
  uncached_buffer = (unsigned char *)(alt_remap_uncached( (void *)(ONCHIP_MEM_32KB_BASE), (alt_u32)(PIX_MAP_WIDTH * PIX_MAP_HEIGHT)));
                
  // set the initial center point, x dimension, and maximum iterations
  center_x = (long long)(in_x * 0x10000000);
  center_y = (long long)(in_y * 0x10000000);
  x_dim = (long long)(in_x_dim * 0x10000000);
  max_iter = in_max_iter;

  // calculate the step dimension between each pixel
  step_dim = x_dim / PIX_MAP_WIDTH;
  
  // calculate the top left pixel value to start with
  current_x = center_x - (x_dim / 2);
  leftmost_x = current_x;
  current_y = center_y + ((PIX_MAP_HEIGHT / 2) * step_dim);
  
  //process the image
    uncached_hw_desc_ptr->current_pixel_count = 0;
    uncached_hw_desc_ptr->x_pixel_count = 0;
    uncached_hw_desc_ptr->max_pixel_count = PIX_MAP_HEIGHT * PIX_MAP_WIDTH;
    uncached_hw_desc_ptr->current_x = current_x;
    uncached_hw_desc_ptr->current_y = current_y;
    uncached_hw_desc_ptr->leftmost_x = leftmost_x;
    uncached_hw_desc_ptr->step_dim = step_dim;
    uncached_hw_desc_ptr->output_buffer_base = (uncached_buffer);
    uncached_hw_desc_ptr->pix_map_height  = PIX_MAP_HEIGHT;
    uncached_hw_desc_ptr->pix_map_width = PIX_MAP_WIDTH;
    uncached_hw_desc_ptr->max_iter = max_iter;
    uncached_hw_desc_ptr->mutex_base = (alt_u32)MUTEX_BASE;
    
    init_c2h_hw_process_image(C2H_INST_0_BASE,((alt_u32)(&hw_desc)), 200);
    start_c2h_hw_process_image(C2H_INST_0_BASE);
    wait_c2h_ready_hw_process_image(C2H_INST_0_BASE);
}
