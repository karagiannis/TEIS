#ifndef ALT_C2H_HW_PROCESS_IMAGE_H_
#define ALT_C2H_HW_PROCESS_IMAGE_H_

void init_c2h_hw_process_image    (
                                        void *c2h_base, 
                                        volatile void *hw_desc,
                                        unsigned short mutex_id
                                    );

void start_c2h_hw_process_image    (
                                        void *c2h_base
                                    );

alt_u32 poll_c2h_ready_hw_process_image    (
                                        void *c2h_base
                                    );

void wait_c2h_ready_hw_process_image    (
                                        void *c2h_base
                                    );

#endif /*ALT_C2H_HW_PROCESS_IMAGE_H_*/
