#ifndef MANDELBROT_H_
#define MANDELBROT_H_

#include "alt_types.h"

typedef volatile struct {
    volatile alt_u32 current_pixel_count;
    volatile alt_u32 x_pixel_count;
    volatile long current_x;
    volatile long current_y;
    volatile alt_u32 max_pixel_count;
    volatile long leftmost_x;
    volatile long step_dim;
    volatile alt_u8 *output_buffer_base;
    volatile alt_u32 *mutex_base;
    volatile short pix_map_height;
    volatile short pix_map_width;
    volatile alt_u8 max_iter;
}MANDELBROT_DESCRIPTOR;

#endif /*MANDELBROT_H_*/
