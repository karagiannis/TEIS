/******************************************************************************
* Copyright � 2006 Altera Corporation, San Jose, California, USA.             *
* All rights reserved. All use of this software and documentation is          *
* subject to the License Agreement located at the end of this file below.     *
*/
#ifndef _REMOTE_CONFIG_H_
#define _REMOTE_CONFIG_H_

#ifndef ALT_INICHE
  #error The Remote Configuration application requires the 
  #error Interniche NichStack IP Software Component
#endif

#ifndef __ucosii__
  #error The Remote Configuration application requires 
  #error the MicroC/OS-II Intellectual Property Software Component.
#endif

/*
 * Task Prototypes:
 */

void RCTask();

extern OS_EVENT *AttainedIPAddressSem;

/*
 *  Task Priorities:
 * 
 *  MicroC/OS-II only allows one task (thread) per priority number.   
 */

#define RC_TASK_PRIORITY  5
#define INITIAL_TASK_PRIORITY               10

/* 
 * The IP, gateway, and subnet mask address below are used as a last resort if 
 * if no network settings can be found, and DHCP (if enabled) fails. You can
 * edit these as a quick-and-dirty way of changing network settings if desired.
 * 
 * Default fall-back address:
 *           IP: 10.0.0.51
 *      Gateway: 10.0.0.255
 *  Subnet Mask: 255.255.255.0
 */
#define IPADDR0   10
#define IPADDR1   0
#define IPADDR2   0
#define IPADDR3   51

#define GWADDR0   10
#define GWADDR1   0
#define GWADDR2   0
#define GWADDR3   255

#define MSKADDR0  255
#define MSKADDR1  255
#define MSKADDR2  255
#define MSKADDR3  0

/* Definition of Task Stacks for tasks not using networking */
#define   TASK_STACKSIZE       1024
#define   INIT_TASK_STACKSIZE  2048

/* TFTP Specific */
/* TFTP op codes. */

#define RRQ 1
#define WRQ 2
#define DATA 3
#define ACK 4
#define ERR 5

/*
 * IP Port for TFTP
 */
 
#define TFTP_PORT 69

/* TFTP error codes. */

#define UNK 0 /* Undefined. */
#define FNF 1 /* File Note found. */
#define AV 2  /* Access violation. */
#define DF 3  /* Disk full. */
#define IL 4  /* Illegal operation. */
#define UNP 5 /* Unknown port. */
#define FAE 6 /* File Already Exists. */
#define NSU 7 /* No such User. */

/* Default reconfig for CIII NEEK board. */
#ifdef REMOTE_UPDATE_NAME
#define RECONFIG_ADDRESS 0xe00000
#endif

#endif //_REMOTE_CONFIG_H_

/******************************************************************************
*                                                                             *
* License Agreement                                                           *
*                                                                             *
* Copyright (c) 2006 Altera Corporation, San Jose, California, USA.           *
* All rights reserved.                                                        *
*                                                                             *
* Permission is hereby granted, free of charge, to any person obtaining a     *
* copy of this software and associated documentation files (the "Software"),  *
* to deal in the Software without restriction, including without limitation   *
* the rights to use, copy, modify, merge, publish, distribute, sublicense,    *
* and/or sell copies of the Software, and to permit persons to whom the       *
* Software is furnished to do so, subject to the following conditions:        *
*                                                                             *
* The above copyright notice and this permission notice shall be included in  *
* all copies or substantial portions of the Software.                         *
*                                                                             *
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR  *
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,    *
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE *
* AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER      *
* LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING     *
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER         *
* DEALINGS IN THE SOFTWARE.                                                   *
*                                                                             *
* This agreement shall be governed in all respects by the laws of the State   *
* of California and by the laws of the United States of America.              *
* Altera does not recommend, suggest or require that this reference design    *
* file be used in conjunction or combination with any other product.          *
******************************************************************************/
