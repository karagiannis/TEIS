#!/bin/bash 

#
# Define Usage() function.
#

Usage(){
  echo ""
  echo "ERROR: There must be at least two arguments passed to this script."
  echo ""
  echo "USAGE: $0 cmd <args>"
  echo "       cmd     = [upload|reconfig]"
  echo "       <args>  = <host> [<filename> when cmd == reconfig]"
  echo ""
  }

tftp_cmd=""
cleanup_cmd=""

#
# Check the number of arguments passed into the script
#
if [ $# -lt 2 ] ; then
  Usage
  exit 1
fi

#
# Assign arguments to sensible local variables.
#
if [ $# -eq 2 ] ; then
  rc_cmd=$1
  host=$2
elif [ $# -eq 3 ] ; then
  rc_cmd=$1
  host=$2
  filename=$3
else # Shouldn't reach here...
  Usage
  exit 1
fi

#
# Now that we have defined our arguments, let's see what platform we're on
# and build our tftp command strings.
#

if [[ "$OSTYPE" == "cygwin" && $rc_cmd == "upload" ]] ; then
  #
  # Assume the version of tftp.exe that is shipped as part of the collateral.
  #
  tftp_cmd="tftp $host PUT $filename"
elif [[ $OSTYPE == "cygwin" && $rc_cmd == "reconfig" ]] ; then
  tftp_cmd="tftp $host GET $rc_cmd"
  cleanup_cmd="rm TFTP*"
elif [[ "$OSTYPE" != "cygwin" && $rc_cmd == "upload" ]] ; then
  #
  # Assume tftp-hpa, which seems to be the most common on Linux systems.
  #
  tftp_cmd="tftp -m ascii $host -c put $filename"
elif [[ "$OSTYPE" != "cygwin" && $rc_cmd == "reconfig" ]] ; then
  tftp_cmd="tftp -m ascii $host -c get $rc_cmd"
  cleanup_cmd="rm reconfig"
else
  #
  # Shouldn't reach here, but if we do, exit with the "Usage echo" and a value of 1 (error).
  #
  Usage
  exit 1
fi

#
# Now, that we've built the tftp_cmd string, check that it's non-empty and execute it.
#
if [ "$tftp_cmd" != "" ] ; then
  eval "$tftp_cmd"
else
  echo "remote_config.sh script failed!  tftp_cmd string is empty!"
  exit 1
fi

#
# Because the tftp "get" command is used to reconfigure the system,
# there are "leftovers".
#   - Since these are empty (and useless) files, remove them before exiting.
#

if [ "$cleanup_cmd" != "" ] ; then
  eval "$cleanup_cmd"
  if [ $? -ne 0 ] ; then
    echo "Running <$cleanup_cmd> command failed!"
    exit 1
  fi
fi
