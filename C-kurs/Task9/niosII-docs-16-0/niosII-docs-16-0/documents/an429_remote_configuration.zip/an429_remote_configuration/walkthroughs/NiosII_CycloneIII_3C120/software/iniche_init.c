/******************************************************************************
* Copyright � 2006 Altera Corporation, San Jose, California, USA.             *
* All rights reserved. All use of this software and documentation is          *
* subject to the License Agreement located at the end of this file below.     *
*/

#include <stdio.h>

/* MicroC/OS-II */
#include "includes.h"

/* Remote Configuration */
#include "remote_config.h"
#include "alt_error_handler.h"
#include "flash_utilities.h"

/* Nichestack */

#include "ipport.h"
#include "libport.h"
#include "osport.h"


extern int current_flash_block;


/* Definition of task stack for the initial task which will initialize the NicheStack
 * TCP/IP Stack and then initialize the rest of this application's tasks.
 */
OS_STK  RCInitialTaskStk[INIT_TASK_STACKSIZE];

/* Declarations for creating a task with TK_NEWTASK.
 * All tasks which use NicheStack (those that use sockets) must be created this way.
 * TK_OBJECT macro creates the static task object used by NicheStack during operation.
 * TK_ENTRY macro corresponds to the entry point, or defined function name, of the task.
 * inet_taskinfo is the structure used by TK_NEWTASK to create the task.
 */
TK_OBJECT(to_rctask);
TK_ENTRY(RCTask);

struct inet_taskinfo rctask = {
      &to_rctask,
      "Remote Configuration Task1",
      RCTask,
      4,
      APP_STACK_SIZE,
};

/* Function which displays the obtained (or assigned) IP
 * Address on the LCD Display.
 */

void lcd_ip_addr()
{
  ip_addr* ipaddr;
  FILE* lcdDevice;

  /* Assign ipaddr to the network interface's IP Address.
   * NOTE:  This code assumes that only a single network
   * interface exists
   */
  ipaddr = &nets[0]->n_ipaddr;

  /* Display the IP Address (initially) on the LCD Display. */
  lcdDevice = fopen( "/dev/lcd_display", "w" );
  fprintf(lcdDevice, "\nIP Address\n%d.%d.%d.%d\n",
        ip4_addr1(*ipaddr),
        ip4_addr2(*ipaddr),
        ip4_addr3(*ipaddr),
        ip4_addr4(*ipaddr));
  fclose( lcdDevice );
}


/* RCInitialTask will initialize the NicheStack
 * TCP/IP Stack and then initialize the rest of this example's
 * RTOS structures and tasks.
 */
void RCInitialTask(void *task_data)
{
  INT8U error_code;

  /*
   * Initialize Altera NicheStack TCP/IP Stack - Nios II Edition specific code.
   * NicheStack is initialized from a task, so that RTOS will have started, and
   * I/O drivers are available.  Two tasks are created:
   *    "Inet main"  task with priority 2
   *    "clock tick" task with priority 3
   */
  alt_iniche_init();
  netmain();

  /* Wait for the network stack to be ready before proceeding.
   * iniche_net_ready indicates that TCP/IP stack is ready, and IP address is obtained.
   */
  while (!iniche_net_ready)
    TK_SLEEP(1);

  /* Now that the stack is running, perform the application initialization steps */

  /* Application Specific Task Launching Code Block Begin */

  printf("\nRemote Configuration Application starting up\n");
#ifndef REMOTE_UPDATE_NAME
  lcd_ip_addr();
#endif

  /* Create the main remote configuration task. */
  TK_NEWTASK(&rctask);

  /* Application Specific Task Launching Code Block End */

  /*This task is deleted because there is no need for it to run again */
  error_code = OSTaskDel(OS_PRIO_SELF);
  alt_uCOSIIErrorHandler(error_code, 0);

  while (1); /* Correct Program Flow should never get here */
}


int main (int argc, char* argv[], char* envp[])
{

  INT8U error_code;

  /* Clear the RTOS timer */
  OSTimeSet(0);

  /* SSSInitialTask will initialize the NicheStack
   * TCP/IP Stack and then initialize the rest of this example's
   * RTOS structures and tasks.
   */
  error_code = OSTaskCreateExt(RCInitialTask,
                             NULL,
                             (void *)&RCInitialTaskStk[INIT_TASK_STACKSIZE],
                             INITIAL_TASK_PRIORITY,
                             INITIAL_TASK_PRIORITY,
                             RCInitialTaskStk,
                             INIT_TASK_STACKSIZE,
                             NULL,
                             0);
  alt_uCOSIIErrorHandler(error_code, 0);

  current_flash_block = UNINITIALIZED;

  /*
   * As with all MicroC/OS-II designs, once the initial thread(s) and
   * associated RTOS resources are declared, we start the RTOS. That's it!
   */
  OSStart();

  while(1); /* Correct Program Flow never gets here. */

  return -1;
}

/******************************************************************************
*                                                                             *
* License Agreement                                                           *
*                                                                             *
* Copyright (c) 2006 Altera Corporation, San Jose, California, USA.           *
* All rights reserved.                                                        *
*                                                                             *
* Permission is hereby granted, free of charge, to any person obtaining a     *
* copy of this software and associated documentation files (the "Software"),  *
* to deal in the Software without restriction, including without limitation   *
* the rights to use, copy, modify, merge, publish, distribute, sublicense,    *
* and/or sell copies of the Software, and to permit persons to whom the       *
* Software is furnished to do so, subject to the following conditions:        *
*                                                                             *
* The above copyright notice and this permission notice shall be included in  *
* all copies or substantial portions of the Software.                         *
*                                                                             *
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR  *
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,    *
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE *
* AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER      *
* LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING     *
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER         *
* DEALINGS IN THE SOFTWARE.                                                   *
*                                                                             *
* This agreement shall be governed in all respects by the laws of the State   *
* of California and by the laws of the United States of America.              *
* Altera does not recommend, suggest or require that this reference design    *
* file be used in conjunction or combination with any other product.          *
******************************************************************************/

