/******************************************************************************
*                                                                             *
* License Agreement                                                           *
*                                                                             *
* Copyright (c) 2006 Altera Corporation, San Jose, California, USA.           *
* All rights reserved.                                                        *
*                                                                             *
* Permission is hereby granted, free of charge, to any person obtaining a     *
* copy of this software and associated documentation files (the "Software"),  *
* to deal in the Software without restriction, including without limitation   *
* the rights to use, copy, modify, merge, publish, distribute, sublicense,    *
* and/or sell copies of the Software, and to permit persons to whom the       *
* Software is furnished to do so, subject to the following conditions:        *
*                                                                             *
* The above copyright notice and this permission notice shall be included in  *
* all copies or substantial portions of the Software.                         *
*                                                                             *
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR  *
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,    *
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE *
* AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER      *
* LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING     *
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER         *
* DEALINGS IN THE SOFTWARE.                                                   *
*                                                                             *
* This agreement shall be governed in all respects by the laws of the State   *
* of California and by the laws of the United States of America.              *
*                                                                             *
* Author - BJR                                                                *
*                                                                             *
* remote_config.c                                                             *
*   Implementation of a remote configuration for Nios II based systems.       *
*   A limited TFTP server is used to receive S-Record formatted FLASH         *
*   files.                                                                    *
*                                                                             *
******************************************************************************/

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include "altera_avalon_pio_regs.h"

/* MicroC/OS-II definitions */
#include "includes.h"

/* Remote Configuration Application definitions */
#include "remote_config.h"
#include "alt_error_handler.h"
#include "flash_utilities.h"

/* Nichestack definitions */
#include "ipport.h"
#include "tcpport.h"

/* Flash definitions*/
#include "sys/alt_flash.h"



/* Globals */

alt_u32 file_size;
int last_block;
extern int current_flash_block;

/* External Function Prototype for the function that Parses the FLASH S-Record
 * and programms it to flash.
 */

extern int ParseSRECBuf( char* buf, int buf_size );

/* Define the various "standard" error strings. */

const char* fnf = "File Not Found.";
const char* av = "Access Violation.";
const char* df = "Disk Full.";
const char* il = "Illegal Operation.";
const char* unp = "Uknown Port.";
const char* fae = "File Already Exists.";
const char* nsu = "No such user.";

OS_EVENT *AttainedIPAddressSem;

/* Various packet structures.
 * For this TFTP implementation we are concerned with 3 types:
 * ACK -> Acknowledgement packets
 * DATA -> DATA packets
 * ERR -> Error packets
 *
 */

struct ack_pkt
{
  alt_u16 opcode;
  alt_u16 blocknum;
};

struct data_pkt
{
  alt_u16 opcode;
  alt_u16 blocknum;
  char  data[512];
};

struct err_pkt
{
  alt_u16 opcode;
  alt_u16 errcode;
  char errstring[80];
};

/*******************************ADDED Initialize PFL OPtion Bits*********************/
void As_InitializePFLOptionBits( unsigned int option_bit_offset )
{

  int i;
  unsigned int* option_bits_buffer;
  unsigned int page_start, page_end;
  alt_flash_fd* flash_fd;

  flash_fd = alt_flash_open_dev( EXT_FLASH_NAME );


  if( flash_fd )
  {
    option_bits_buffer = malloc( 256 );
    if( option_bits_buffer != NULL )
    {
      memset( option_bits_buffer, 0xFF, 256 );
            for( i = 0; i < 8; i++ )
      {
page_start = ( AS_SELECTOR_HW_IMAGE_OFFSET + ( 0x380000 * i ));
page_end = page_start + 0x380000;
//page_end = page_start + 0x370000;

    	  printf("Page Start - %x, Page End - %x\n" , page_start, page_end);
        option_bits_buffer[i] = ( page_end << 4 ) | ( page_start >> 12 );

      }

      // The byte following the 128-byte option bit section must be 0x2
      // this causes the PFL to treat the configuration pages as RBFs.
      // A 0x3 causes the PFL to treat them as "packetized" config data.
      // We want RBF.
            option_bits_buffer[32] = 0xFFFFFF03;  // uncompressed
      //option_bits_buffer[32] = 0xFFFFFF02;  // uncompressed
//option_bits_buffer[32] = 0xFFFFFF03;  // compressed

      if( memcmp( option_bits_buffer, (void*)(flash_fd->base_addr + option_bit_offset), 256 ))
      {
#if USE_SPANSION_FLASH_DRIVER
        flash_spansion_s29gln_erase ( (int)flash_fd->base_addr, option_bit_offset, AS_FLASH_SECTOR_SIZE );
        flash_spansion_s29gln_write ( (int)flash_fd->base_addr, option_bit_offset, (void*)option_bits_buffer, 256 / 2 );
#elif USE_HAL_FLASH_DRIVER
        alt_erase_flash_block( flash_fd, option_bit_offset, AS_FLASH_SECTOR_SIZE );
        alt_write_flash_block( flash_fd, option_bit_offset, option_bit_offset, (void*)option_bits_buffer, 256 );
#endif
      }

      free( option_bits_buffer );
    }

    alt_flash_close_dev( flash_fd );
  }
}

//ADDED convert_offset_to_page func
int convert_offset_to_page( int hw_offset )
{
 int hw_flash_page;
 hw_flash_page = (hw_offset - AS_SELECTOR_HW_IMAGE_OFFSET)/0x380000;

 return hw_flash_page;
}

///************************Reconfig FPGA Function using the Max2 device
#ifdef MAX2_NAME

void reconfig_fpga()
{

  volatile int hw_offset = RECONFIG_ADDRESS;
  int hw_flash_page = convert_offset_to_page( hw_offset );
  printf("WS RESET:  Reconfiguring to offset 0x%x, PFL page %d.\n", hw_offset, hw_flash_page );
  printf("%c", 0x4);
  OSTimeDlyHMSM(0, 0, 3, 0);

  AsReconfigFPGA( hw_flash_page );

}

int AsReconfigFPGA( unsigned int hw_flash_page )
{
  unsigned int reconfig_reg;


  //As_InitializePFLOptionBits( 0x3FE0000 );
  //Enable AS_InitialiazePFLOptionBits if your option bit has been modified before.
  while( 1 )
  {
	  reconfig_reg = 0;
	  reconfig_reg = IORD_32DIRECT( MAX2_BASE, 0x8 );

    // Clear the page select register bits
    reconfig_reg &= AS_MAXII_CLEAR_PSR_MASK;

    // Clear the reset select bit so that we reconfigure from the
    // PSR (page select register), not the PSS (page select switch)
    reconfig_reg &= AS_MAXII_CLEAR_PSO_MASK;

    // Now set the page selection register
  reconfig_reg |= ( hw_flash_page << 6 ); //6

    IOWR_32DIRECT( MAX2_BASE, 0x8, reconfig_reg  );

    // Now reconfigure the fpga
    reconfig_reg |= AS_MAXII_FORCE_RECONFIG_MASK;
    IOWR_32DIRECT( MAX2_BASE, 0x8, reconfig_reg  );
  }
}
// ADDED MAX 2



/*******************************ADDED MAX 2 END********************************/



/* void
reconfig_fpga()
{
  volatile int remote_update_base;
  volatile int hw_flash_offset;

  remote_update_base = REMOTE_UPDATE_BASE;
  hw_flash_offset = RECONFIG_ADDRESS;
  printf("Debug#1 - Remote Update base = %x \n", remote_update_base);
  printf("Debug#2 - Hardware flash offset = %x \n", hw_flash_offset);

  printf("Debug#3 - DY: Ensuring flash is in read mode\n");
    // Make sure the flash is in read mode
  IOWR_16DIRECT( EXT_FLASH_BASE, 0, 0xFFFF );
  IOWR_8DIRECT( EXT_FLASH_BASE, 0, 0xFF );

  printf("Debug#4 - Disabling watchdog timer\n");
  // First disable the watchdog timer
  IOWR( remote_update_base, 0x3, 0  );

  usleep(1000);

  printf("Debug#5 - Writing offset of hardware image in flash\n");
  // Next write the offset of the hardware image in flash
  IOWR( remote_update_base, 0x4, hw_flash_offset >> 3  );

  usleep(1000);

  printf("Debug#6 - Reconfiguring\n");
  // Reconfigure
  IOWR( remote_update_base, 0x20, 0x1 );

  while( 1 );

  return;
}
*/
#else /* No remote_update block....not a CIII NEEK board. */

void
reconfig_fpga()
{
  IOWR_ALTERA_AVALON_PIO_DATA( RECONFIG_REQUEST_PIO_BASE, 0x0 );
  /* Set BIDIR PIO to drive out. */
  IOWR_ALTERA_AVALON_PIO_DIRECTION( RECONFIG_REQUEST_PIO_BASE, 1 );
  usleep( 1000000 );
  /* Drive out a 1....probably won't reach this point!!! */
  IOWR_ALTERA_AVALON_PIO_DATA( RECONFIG_REQUEST_PIO_BASE, 0x1 );
  /* Though this doesn't matter, since reconfiguration will have
  * already started....  Should still do something responsible.
  */
  while(1);
}

#endif

/******************************************************************
*  Function: send_ERR
*
*  Purpose: Function which constructs and sends an appropriate ERR
*           packet.
*
******************************************************************/

error_t
send_ERR( int error, char *mesg, int fd, struct sockaddr* addr )
{
  error_t err;
  struct err_pkt *pkt = (struct err_pkt*) malloc(84) ;

  pkt->opcode = htons( 0x5 );
  pkt->errcode = htons( error );

  switch( error )
  {
    case UNK:
      strcpy( pkt->errstring, mesg );
      break;
    case FNF:
      strcpy( pkt->errstring, fnf );
      break;
    case AV:
      strcpy( pkt->errstring, av );
      break;
    case DF:
      strcpy( pkt->errstring, df );
      break;
    case IL:
      strcpy( pkt->errstring, il );
      break;
    case UNP:
      strcpy( pkt->errstring, unp );
      break;
    case FAE:
      strcpy( pkt->errstring, fae );
      break;
    case NSU:
      strcpy( pkt->errstring, nsu );
      break;
    default:
      printf("\nTFTP ERROR:  Reached illegal state in errcode fsm!");
      break;
  }

  printf( "Error code = %d\n", pkt->errcode );
  printf( "Error string = %s\n", pkt->errstring );

  /* Send the error packet. */
  err = sendto( fd, pkt, 84, 0, addr, sizeof(*addr) );
  free( pkt );
  return err;
}


/******************************************************************
*  Function: send_ACK
*
*  Purpose: Function which constructs and sends an ACK packet.
*
******************************************************************/

error_t
send_ACK( alt_u16 block_number, int fd, struct sockaddr* addr )
{
  error_t  err = OS_NO_ERR;
  struct ack_pkt pkt;

  /* Build the packet to send. */

  pkt.opcode = htons(0x4);
  pkt.blocknum = htons( block_number );

  /* Send the packet. */

  err = sendto( fd, &pkt, sizeof( pkt ), 0, addr, sizeof(*addr) );

  return err;
}

/******************************************************************
*  Function: tftp_fsm
*
*  Purpose: Function which detects the type of packet (based on
*           the opcode) which was received on port 69.  The
*           following opcodes are supported:
*           1.  RRQ (Read Request)
*             - currently only supports the "reconfig" option.
*               Any other name will return an FNF (file not found)
*               error.
*           2.  WRQ (Write Request)
*             - currently only supports files generated for use
*               by the Nios II Flash Programmer (.flash files).
*               Any other filename will generate a FNF error.
*           3.  DATA (Data packets)
*             - currently only supports the receipt of .flash (S-Record)
*               packets.
*               Each 512 byte packet is parsed and programmed as it is
*               received.
*
******************************************************************/

error_t
tftp_fsm( int fd, int size, void* recv_payload_ptr, struct sockaddr* addr )
{
  error_t   err;
  /* The opcode is the first 2 bytes of any received packet. */
  alt_u16 opcode = ntohs( *((alt_u16*) recv_payload_ptr) );
  /* The block number follows the opcode in a DATA packet. */
  alt_u16 blocknum;
  /* The filename follows the opcode in a WRQ/RRQ packet.
   * Valid extensions are either .flash or .srec.
   *  - Detecting anything else returns an FNF error.
   *    - Logic is contained in the WRQ case, below.
   */
  char* filename;
  int ext;
  /* A buffer to hold S-Record contents. */
  char* srec_buf[512];
  /* position within the buffer. */
  char* data_pos;

  switch ( opcode )
  {
    case RRQ:
      filename = (char*) (recv_payload_ptr+2);
      if ( (strcmp( filename, "reconfig" ) ) == 0 )
      {
        err = send_ERR( UNK, "Nios II Based System will now reconfigure!!!\r\n\0", fd, addr );
        reconfig_fpga();
	printf( "\n\nTFTP Error:  reconfig RRQ failed!  Please check your reconfig_fpga() function!\n");
        break;
      }
      err = send_ERR( FNF, NULL, fd, addr );
      break;
    case WRQ:
      /* Send an ACK with block number 0 to start the WRQ process. */
      filename = (char*) (recv_payload_ptr+2);
      /* Check for srec. */
      ext = (int) (filename + strlen(filename) - 4);
      if ( !strcmp((char*) ext, "srec" ) )
      {
        printf("Received an SREC file.\n");
        err = send_ERR( UNK, "Got an SREC file....not yet supported.", fd, addr );
        break;
      }
      ext = (int) (filename + strlen(filename) - 5);
      if ( !strcmp((char*) ext, "flash") )
      {
        printf("\n\nReceiving a FLASH file.\n");
        err = send_ACK( 0, fd, addr );
        break;
      }
      err = send_ERR( FNF, NULL, fd, addr );
      break;
    case DATA:
      blocknum = ntohs( *((alt_u16*) recv_payload_ptr + 1) );
      //printf( "Received Block Number %d.\n", blocknum );
      if ( blocknum != last_block )
      {
        data_pos = (char*) recv_payload_ptr + 4;
        /* Copy the data into the srec_buf. */
        memcpy((void*) srec_buf, (void*) data_pos, (size - 4));
        /* Parse/Program the SREC buffer. */
        if( (ParseSRECBuf( (char*) srec_buf, (size - 4 - 1))) == 0 )
        {  /* Send an ACK packet. */
          last_block = blocknum;
          err = send_ACK( blocknum, fd, addr );
          if( (size - 4) < 512 )
          {
            printf( "\n\nFlash programming completed.\n" );
          }
        } else
        {
          err = send_ERR( UNK, "SREC Parsing or Flash Programming failed!", fd, addr );
        }
      } else break;
      break;

    default:
      printf( "\n TFTP ERROR:  tftp_server illegal state reached!\n" );
      break;
  }

  return err;
}

/******************************************************************
*  Function: RCTask
*
*  Purpose: Top level TFTP task responsible for creating
*           the UDP socket (port 69) and passing control to
*           tftp_fsm() for each packet received.
*           NOTE:  Simultaneous TFTP transactions are not supported!
*
******************************************************************/

void RCTask()
{
  struct  sockaddr_in addr, pc_addr;
  error_t   err;
  size_t  size;
  int tftp_fd, pc_addr_len=sizeof(pc_addr);
  alt_u8	recv_payload[1500];

  tftp_fd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
  if (tftp_fd < 0)
    goto exit;

  /*
   * Bind to the well-known TFTP port:  69
   */
  addr.sin_family = AF_INET;
  addr.sin_addr.s_addr = INADDR_ANY;
  addr.sin_port = htons(TFTP_PORT);

  err = bind(tftp_fd, (struct sockaddr *)&addr, sizeof(addr));
  if (err)
  {
    printf("Can't bind tftp_server to port 69.\n");
    goto exit;
  }

  /*
   * Receive data/process payload.
   */
  while(1)
  {
    size = recvfrom(tftp_fd, recv_payload, sizeof(recv_payload), 0,
                   (struct sockaddr *)&pc_addr, &pc_addr_len);
    if (size > 0)
    {
      /* Process TFTP payloads. */
      err = tftp_fsm( tftp_fd, size, (void*) &recv_payload, (struct sockaddr *)&pc_addr );
    }
    else
    {
      printf( "\nTFTP_ERR:  Error in packet reception. ERRNO = %d.", errno );
      return;
    }
  }
exit:
  if (tftp_fd >= 0)
    close(tftp_fd);
  return ;

}

/******************************************************************************
*                                                                             *
* License Agreement                                                           *
*                                                                             *
* Copyright (c) 2006 Altera Corporation, San Jose, California, USA.           *
* All rights reserved.                                                        *
*                                                                             *
* Permission is hereby granted, free of charge, to any person obtaining a     *
* copy of this software and associated documentation files (the "Software"),  *
* to deal in the Software without restriction, including without limitation   *
* the rights to use, copy, modify, merge, publish, distribute, sublicense,    *
* and/or sell copies of the Software, and to permit persons to whom the       *
* Software is furnished to do so, subject to the following conditions:        *
*                                                                             *
* The above copyright notice and this permission notice shall be included in  *
* all copies or substantial portions of the Software.                         *
*                                                                             *
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR  *
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,    *
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE *
* AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER      *
* LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING     *
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER         *
* DEALINGS IN THE SOFTWARE.                                                   *
*                                                                             *
* This agreement shall be governed in all respects by the laws of the State   *
* of California and by the laws of the United States of America.              *
* Altera does not recommend, suggest or require that this reference design    *
* file be used in conjunction or combination with any other product.          *
******************************************************************************/
