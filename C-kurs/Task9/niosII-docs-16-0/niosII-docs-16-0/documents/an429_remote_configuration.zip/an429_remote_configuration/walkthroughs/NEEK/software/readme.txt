Remote Configuration Application
================================
The files contained in this project comprise a remote configuration over
TFTP implementation.  For details on the TFTP protocol, please search
for "TFTP description" in your favorite web search engine.


NOTE:  For program-level details please see the source code comments.

What this program does:
==================
Implements a TFTP server where "PUT"ting or uploading "FLASH" files will
cause them to be programmed to the flash of your choice.  Both CFI and
EPCS devices are supported, but not simulataneously.

NOTE:  The type of flash is chosen by setting DEFAULT_FLASH_TYPE in
       flash_utilities.h.
       - The following "mapping" is supported:
       	CFI <=> "/dev/ext_flash"
       	EPCS <=> "/dev/epcs_controller"
       If your names are different, then you'll have to modify the code
       in flash_utilities.c to support your flash.
       
This TFTP server only supports what is necessary to program images
and reconfigure the device.
	- This amounts to reasonably complete WRQ (write request) detection,
	  a reasonably complete DATA (data packet) handler, and a crippled
	  RRQ (read request) detection.  See the in-line comments for details!
	  
Usage flow: 
=========================================
NOTE:  assumes that the source for this project already resides in your
software examples directory
	1.  Create the FLASH (.flash) images that you wish to upload.
	    - This has already been done for you if you've previously
	      programmed your software/hardware to flash using the
	      Nios II Flash Programmer.
	2.  Program your FPGA with a standard or full-featured design.
	    	   The EP1C12 Nios II Eval. Kit is not supported due to lack of ethernet support.	
	3.  Create a "Remote Configuration" project.
	4.  If necessary, edit flash_utilities.h to match your system.
	5.  Build the project in the Nios II IDE.
	6.  Run the project from within the Nios II IDE.
	7.  Pay attention to the IP Address that is attained.
	8.  Upload your image(s) using the TFTP client application of your choice.
		Looks something like this:
		tftp <host> PUT <your_image.flash>
			-- Uploading, SREC parsing and flash programming is done.
			-- May be done as many times as necessary.
		   	NOTE:  multiple FLASH files may be combined (concatenated) into a single FLASH file as well.
		tftp <host> GET reconfig
			-- Triggers a reconfiguration.

Nuggets of knowledge (most of this can be obtained elsewhere):
======================
* Useful flash programming commands:
	- Erasing the flash 
		nios2-flash-programmer [--epcs] --base=<flash base> --erase-all
	  		or
	  	nios2-flash-programmer [--epcs] --base=<flash base> --erase=<start>,<size>
	- Reading data range from flash
		nios2-flash-programmer [--epcs] --base=<flash base> --read=<data.srec> --read-bytes=<start>,<size>
    - General command line for creating a "FLASH" file
    	...from an ELF:  elf2flash --base=<flash base> --end=<flash end> --reset=<reset address> --input=<input ELF>
    	                 --output=<output FLASH> --boot=<boot copier SREC>
    	...from a SOF:   sof2flash --offset=<offset from flash base> --input=<input SOF> --output=<output FLASH>
    	...from a binary:  bin2flash --base=<flash base> --location=<offset from flash base> --input=<binary file>
    	                   --output=<output FLASH>
	- Getting information about a flash device
		nios2-flash-programmer [-epcs] --debug --base=<flash_base>
			- For CFI flash, this dumps the CFI table.
			- For EPCS, this dumps useful EPCS registers and their initial values.
* Upload Throughput
	NOTE:  Keep in mind that the Remote Configuration application is parsing text files (S-Records)
		   and then programming the data (line-by-line) to flash.
	- Better performance (20-25% better on a Nios II/f running on a Stratix II) can be achieved by 
	  using the "Release" set of compilation options.
	- Performance will be, ultimately, limited by the write/program timings to your flash device.
	- Removing S-Record parsing from the programming path should increase performance dramatically.
