Application Note 429 - Remote Configuration over Ethernet with the Nios II Processor V3.0

This file contains the following sections:

o  Package Contents		
o  Tool Requirements		
o  What this program does
0  Remote Configuration Application	
o  General Usage flow: 
0  Useful Information
0  Release History
o  Contacting Altera		


Package Contents
================

ReadMe.txt:  This file. Expert users might need only this file in order to get up and running.

src/SBT_flow:  A remote_config.zip file of a software template suitable for use with the Nios II IDE.
- Just unzip into your $SOPC_KIT_NIOS2/examples/software directory, and you'll be able to use it like any of the other (already included) software examples/templates.

src/CLI_flow:  An rc_iniche.zip file with rc_iniche application and accompanying rc_iniche_bsp BSP.  Pay close attention to the create-this-[app|bsp] scripts, and, in particular the hardcoded variables at the top of each script.  You might need to change these based upon where you choose to unzip this file. By default, they should function when unzipping into the directory where the .sopc file resides.
NOTE:  Modify the DEFAULT_LAN_DEVICE to reflect what you have in your system.
Once you have correct settings in your create-this-[app|bsp] scripts, the basic flow is:
1.  ./create-this-app
2.  nios2-configure-sof <your sof>
3.  At this point, you should see the startup sequence...and DHCP IP acquisition.

walkthroughs/remote_config.sh:  A remote_config.sh bash script which wraps the two TFTP-based commands
                                for "upload" and "reconfig".
			          - It does this for the included tftp.exe (mentioned above)
				    on Win32 platforms, and for the popular tftp-hpa (OpenBSD tftp)
				    on Linux platforms.
				  - It is provided without guarantee of functionality, though making
				    it function on your system shouldn't be too difficult.
walkthroughs/tftp.exe:  A tftp.exe that you can locate in your path to
                        facilitate remote configuration from a Win32 PC.
walkthroughs/<board_name>  Board-specific walkthrough files.


For program level help, please refer to the source code comments.

Tools Requirements
==================
This design requires the following:

- Quartus II software version 9.1 or later, including SOPC Builder
- Nios II Embedded Design Suite version 9.1 or later
- Knowledge of Altera configuration methodologies.
- Knowledge of network programming, preferably sockets-based programming.
- Experience with the Nios II flash programmer using the GUI in the Nios II Software Build Tools for Eclipse or using the command-line interface.
- Knowledge of the Motorola S�Record format, which is used for all flash programming and remote configuration images.
- A TFTP client (an example TFTP client is provided in this example).

What this program does:
==================
Implements a TFTP server where "PUT"ting or uploading "FLASH" files will
cause them to be programmed to the flash of your choice.  Both CFI and
EPCS devices are supported, but not simulataneously.

NOTE:  The type of flash is chosen by setting DEFAULT_FLASH_TYPE in
       flash_utilities.h.
       - The following "mapping" is supported:
       	CFI <=> "/dev/ext_flash"
       	EPCS <=> "/dev/epcs_controller"
       If your names are different, then you'll have to modify the code
       in flash_utilities.c to support your flash.
       
This TFTP server only supports what is necessary to program images
and reconfigure the device.
	- This amounts to reasonably complete WRQ (write request) detection,
	  a reasonably complete DATA (data packet) handler, and a crippled
	  RRQ (read request) detection.  See the in-line comments for details!


Remote Configuration Application(both command line and SBTE)
================================
The files contained in this project comprise a remote configuration over
TFTP implementation.  For details on the TFTP protocol, please search
for "TFTP description" in your favorite web search engine.


General Usage flow: 
=========================================
NOTE:  assumes that the source for this project already resides in your
software examples directory
UPDATED:  The walkthrough directory contains the necessary hardware, software (SOF, ELF) and flash contents to "test" the following flow.
	1.  Create the FLASH (.flash) images that you wish to upload.
	    - This has already been done for you if you've previously
	      programmed your software/hardware to flash using the
	      Nios II Flash Programmer.
	2.  Program your FPGA with a standard or full-featured design.
	3.  Create a "Remote Configuration" project (in the SBTE, or just change to the location of the create-this-app script for the CLI flow).
	4.  If necessary, edit flash_utilities.h to match your system.
	5.  Build the project in the Nios II SBT (or by running the 'create-this' script in the CLI flow)
	6.  Run the project from within the Nios II SBT.
	    - Or via the command line sequence "nios2-download -g <ELF exe> && nios2-termminal".
	7.  Pay attention to the IP Address that is attained.



Useful Information (most of this can be obtained elsewhere):
==================
* Useful flash programming commands:
	- Erasing the flash 
		nios2-flash-programmer [--epcs] --base=<flash base> --erase-all
	  		or
	  	nios2-flash-programmer [--epcs] --base=<flash base> --erase=<start>,<size>
	- Reading data range from flash
		nios2-flash-programmer [--epcs] --base=<flash base> --read=<data.srec> --read-bytes=<start>,<size>
    - General command line for creating a "FLASH" file
    	...from an ELF:  elf2flash --base=<flash base> --end=<flash end> --reset=<reset address> --input=<input ELF>
    	                 --output=<output FLASH> --boot=<boot copier SREC>
    	...from a SOF:   sof2flash --offset=<offset from flash base> --input=<input SOF> --output=<output FLASH>
    	...from a binary:  bin2flash --base=<flash base> --location=<offset from flash base> --input=<binary file>
    	                   --output=<output FLASH>
	- Getting information about a flash device
		nios2-flash-programmer [-epcs] --debug --base=<flash_base>
			- For CFI flash, this dumps the CFI table.
			- For EPCS, this dumps useful EPCS registers and their initial values.
* Upload Throughput
	NOTE:  Keep in mind that the Remote Configuration application is parsing text files (S-Records)
	and then programming the data (line-by-line) to flash.
	- Performance will be, ultimately, limited by the write/program timings to your flash device.
	- Removing S-Record parsing from the programming path should increase performance dramatically.



Release History
===============

Version 1.0
-----------
Initial Release

Version 1.1
-----------
Added command-line flow functionality for expert users.

Version 2.0
-----------
Updated to describe new design files. Added the Board Update Portal.

Version 3.0
-----------
Updated contents to support Nios II Software Build Tools for Eclipse.
Added support for the 3C120 board and MAX II PFL component.
Removed support for older boards.




Contacting Altera
=================

Although we have made every effort to ensure that this version of the Remote Configuration over Ethernet with the Nios II Processor design works correctly, there may be problems that we have not encountered. If you have a question or problem that is not answered by the information provided in this readme file, please contact your Altera Field Applications Engineer.

If you have additional questions that are not answered in the documentation
provided with this design, contact Altera Applications using one of the
following methods:

Technical Support Hotline:  (800) 800-EPLD (U.S.)
                            (408) 544-7000 (Internationally)
World wide web:             http://www.altera.com/mysupport

Last updated December, 2009
Copyright � 2009 Altera Corporation. All rights reserved.
