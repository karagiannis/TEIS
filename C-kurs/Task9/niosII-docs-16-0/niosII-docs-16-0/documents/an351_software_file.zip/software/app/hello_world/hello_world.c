#include <stdio.h>
#include "system.h"
#include "altera_avalon_pio_regs.h"

int main ()
{
    int i;
	
	//Send a message to console
    printf("Hello from Nios II!\n");
    
	//Blink the LEDs in a counting-up manner from 0 to 255
    for(i=0;i<256;i++) 
    {
        /*This writes values to the LEDs using macro defined in altera_avalon_pio_regs.h
		This macro accepts two arguments: the base address of the PIO and the value that will be written to the PIO. 
		In this example, the PIO base address is defined in the system.h file to be LED_PIO_BASE.*/
		IOWR_ALTERA_AVALON_PIO_DATA(LED_PIO_BASE,i);
    }
    
    return 0;
    
}
