Hello World prints 'Hello from Nios II' to STDOUT.    
    
This example runs with or without the MicroC/OS-II RTOS and requires an STDOUT device in your system's hardware.    
    
This software example runs on the following Nios II hardware designs:    
   - Standard    
   - Full Featured    
   - Fast    
   - Low Cost    
    
For details, click Finish to create the project and refer to the readme.txt file in the project directory.    
