/*************************************************************************
* Copyright � 2004 Altera Corporation, San Jose, California, USA.        *
* All rights reserved. All use of this software and documentation is     *
* subject to the License Agreement located at the end of this file below.*
*************************************************************************/
/******************************************************************************
 *
 * Description
 * ************* 
 * This program compares the performance of floating point addition, 
 * subtraction, multiplication and division using the Nios II floating point 
 * custom instruction vs software.  Each operation involves 2 single precision 
 * (float) operands and returns a single precision result (float).
 * 
 * After each operation is performed, a table is printed to stdout showing the
 * performance using the floating point custom instruction and software.
 * 
 * Requirements
 * **************
 * This program requires the following devices to be configured:
 *   Performance Counter named "PERFORMANCE_COUNTER" with at least 2 sections
 *    
 * Peripherals Exercised by SW
 * *****************************
 * Performance Counter
 * UART (JTAG or serial)
 *
 * Software Files
 * ****************
 * floating_point.c    ==> (This file) main() is contained here. Performs 
 *                         floating point operations using Nios II floating 
 *                         point custom instruction and sofware. Displays the 
 *                         performance for each operation.
 * floating_point_SW.c ==> Contains functions which perform +, -, *, / 
 *                         operations through calls to the floating-point 
 *                         library routines.                        
 * floating_point.h    ==> #defines and function prototypes
 * 
 * Notes
 * *******
 * The functions for performing the floating point operations in software are 
 * in a separate file. This is done so that a #pragma statement can be used to
 * tell the compiler to perform the floating point operation through a call to 
 * the floating-point library routine rather than use the Nios II custom 
 * instruction.  The compiler applies the #pragma statement to each compilation 
 * unit (i.e. each source file).
 */

#include <stdio.h> 
#include <stdlib.h> /* rand(), RAND_MAX */
#include <math.h>   /* exp, log */
#include <float.h>  /* FLT_MAX */ 
#include <sys/alt_irq.h>
#include "altera_avalon_performance_counter.h"
#include "system.h"
#include "floating_point.h"

#define NUM_ITERATIONS 1000

int main(void)
{
  int i;

  float random_a[NUM_ITERATIONS];
  float random_b[NUM_ITERATIONS];
  
  float result_CI;
  float result_SW; 

  alt_irq_context context;

 #if 0
  /* Generate random floating point numbers and place them in 2 arrays, one for 
   * each operand.  The range is -FLT_MAX to FLT_MAX.  The exp() and log() are
   * is used to get a non-linear distribution (without them the numbers aren't 
   * distributed well).*/  
  for (i = 0; i < NUM_ITERATIONS; i++)
  {
    random_a[i] = (float) exp((rand()/(double)RAND_MAX) * log(FLT_MAX));
    if (rand() > RAND_MAX / 2) random_a[i] = -random_a[i];
    
    random_b[i] = (float) exp((rand()/(double)RAND_MAX) * log(FLT_MAX));
    if (rand() > RAND_MAX / 2) random_b[i] = -random_b[i]; 
  }
#endif

  /* Generates random floating points numbers within range 0 and 1.
   * This is for the ease of simple comparisons for results have different
   * rounding schemes between FPCI2 and software emulation
   */
  for (i = 0; i < NUM_ITERATIONS; i++)
  {
	random_a[i] = (float) (rand()/(double)RAND_MAX);
	if (rand() > RAND_MAX / 2) random_a[i] = -random_a[i];

	random_b[i] = (float) (rand()/(double)RAND_MAX);
	if (rand() > RAND_MAX / 2) random_b[i] = -random_b[i];
  }

  /************************************************
   * Floating Point calculations
   ************************************************/
  /************************************************
   * ADD
   ************************************************/ 
  PERF_RESET (PERIPHERAL_SUBSYSTEM_PERFORMANCE_COUNTER_BASE);
  PERF_START_MEASURING (PERIPHERAL_SUBSYSTEM_PERFORMANCE_COUNTER_BASE);
  
	for (i = 0; i < NUM_ITERATIONS; i++)
  {
	  context = alt_irq_disable_all();
    
    result_CI = fp_add_CI(random_a[i], random_b[i]);
    result_SW = fp_add_SW(random_a[i], random_b[i]);
     
    alt_irq_enable_all(context);  

    // FPCI2 vs software emulation have different rounding schemes, hence slight variations in results
    if (fabsf(result_CI - result_SW) >= 0.00001)
    {
      printf("\nCustom instruction result does not match software result. See below.");
      printf("\nCI: %f + %f = %f", random_a[i], random_b[i], result_CI);
      printf("\nSW: %f + %f = %f", random_a[i], random_b[i], result_SW);
    }
  }
  PERF_STOP_MEASURING (PERIPHERAL_SUBSYSTEM_PERFORMANCE_COUNTER_BASE);
  printf("\n\n");
  perf_print_formatted_report  ((void *)PERIPHERAL_SUBSYSTEM_PERFORMANCE_COUNTER_BASE,   /* defined in "system.h" */
                                ALT_CPU_FREQ,                       /* defined in "system.h" */
                                2,                                  /* How many sections to print */
                                "FP CI ADD",                        /* Display-name of section(s) */
                                "FP SW ADD");                       /* ... */

  
  /************************************************
   * SUBTRACT
   ************************************************/ 
  PERF_RESET (PERIPHERAL_SUBSYSTEM_PERFORMANCE_COUNTER_BASE);
  PERF_START_MEASURING (PERIPHERAL_SUBSYSTEM_PERFORMANCE_COUNTER_BASE);
  for (i = 0; i < NUM_ITERATIONS; i++)
  {
    context = alt_irq_disable_all();
     
    result_CI = fp_sub_CI(random_a[i], random_b[i]);
    result_SW = fp_sub_SW(random_a[i], random_b[i]);
          
    alt_irq_enable_all(context); 
          
    // FPCI2 vs software emulation have different rounding schemes, hence slight variations in results
    if (fabsf(result_CI - result_SW) >= 0.00001)
    {
      printf("\nCustom instruction result does not match software result. See below.");
      printf("\nCI: %f - %f = %f", random_a[i], random_b[i], result_CI);
      printf("\nSW: %f - %f = %f", random_a[i], random_b[i], result_SW);
    }
  }
  PERF_STOP_MEASURING (PERIPHERAL_SUBSYSTEM_PERFORMANCE_COUNTER_BASE);
  printf("\n\n");
  perf_print_formatted_report  ((void *)PERIPHERAL_SUBSYSTEM_PERFORMANCE_COUNTER_BASE,   /* defined in "system.h" */
                                ALT_CPU_FREQ,                       /* defined in "system.h" */
                                2,                                  /* How many sections to print */
                                "FP CI SUBTRACT",                   /* Display-name of section(s) */
                                "FP SW SUBTRACT");                  /* ... */
  
   
  /************************************************
   * MULTIPLY
   ************************************************/ 
  PERF_RESET (PERIPHERAL_SUBSYSTEM_PERFORMANCE_COUNTER_BASE);
  PERF_START_MEASURING (PERIPHERAL_SUBSYSTEM_PERFORMANCE_COUNTER_BASE);
  for (i = 0; i < NUM_ITERATIONS; i++)
  {
    context = alt_irq_disable_all();
     
    result_CI = fp_mul_CI(random_a[i], random_b[i]);
    result_SW = fp_mul_SW(random_a[i], random_b[i]);
    
    alt_irq_enable_all(context); 
     
    // FPCI2 vs software emulation have different rounding schemes, hence slight variations in results
    if (fabsf(result_CI - result_SW) >= 0.00001)
    {
      printf("\nCustom instruction result does not match software result. See below.");
      printf("\nCI: %f * %f = %f", random_a[i], random_b[i], result_CI);
      printf("\nSW: %f * %f = %f", random_a[i], random_b[i], result_SW);
    }
  }
  PERF_STOP_MEASURING (PERIPHERAL_SUBSYSTEM_PERFORMANCE_COUNTER_BASE);
  printf("\n\n");
  perf_print_formatted_report  ((void *)PERIPHERAL_SUBSYSTEM_PERFORMANCE_COUNTER_BASE,   /* defined in "system.h" */
                                ALT_CPU_FREQ,                       /* defined in "system.h" */
                                2,                                  /* How many sections to print */
                                "FP CI MULTIPLY",                   /* Display-name of section(s) */
                                "FP SW MULTIPLY");                  /* ... */
  
                       
  /************************************************
   * DIVIDE
   ************************************************/                               
  PERF_RESET (PERIPHERAL_SUBSYSTEM_PERFORMANCE_COUNTER_BASE);
  PERF_START_MEASURING (PERIPHERAL_SUBSYSTEM_PERFORMANCE_COUNTER_BASE);
  for (i = 0; i < NUM_ITERATIONS; i++)
  {
    context = alt_irq_disable_all();
     
    result_CI = fp_div_CI(random_a[i], random_b[i]);
    result_SW = fp_div_SW(random_a[i], random_b[i]);
     
    alt_irq_enable_all(context);  
     
    // FPCI2 vs software emulation have different rounding schemes, hence slight variations in results
    if (fabsf(result_CI - result_SW) >= 0.00001)
    {
      printf("\nCustom instruction result does not match software result. See below.");
      printf("\nCI: %f / %f = %f", random_a[i], random_b[i], result_CI);
      printf("\nSW: %f / %f = %f", random_a[i], random_b[i], result_SW);
    }
  }
  PERF_STOP_MEASURING (PERIPHERAL_SUBSYSTEM_PERFORMANCE_COUNTER_BASE);
  printf("\n\n");
  perf_print_formatted_report  ((void *)PERIPHERAL_SUBSYSTEM_PERFORMANCE_COUNTER_BASE,   /* defined in "system.h" */
                                ALT_CPU_FREQ,                       /* defined in "system.h" */
                                2,                                  /* How many sections to print */
                                "FP CI DIVIDE",                     /* Display-name of section(s) */
                                "FP SW DIVIDE");                    /* ... */              
  return 0;
}
