#include <stdio.h>
#include "altera_avalon_performance_counter.h"
#include "system.h"
#include "altera_avalon_timer_regs.h"
#include "sys/alt_irq.h"

#ifdef ALT_ENHANCED_INTERRUPT_API_PRESENT
void timer_interrupt_latency_init (void* base, alt_u32 irq_controller_id, alt_u32 irq);
void timer_interrupt_latency_irq (void* base);
#else
void timer_interrupt_latency_init (void* base, alt_u32 irq);
void timer_interrupt_latency_irq (void* base, alt_u32 id);
#endif
volatile alt_u32 interrupt_watch_value;

#define EOT 0x4

#define PERF_COUNTER_BASE PERFORMANCE_COUNTER_0_BASE

int main()
{
  alt_u16 period_lower;
  alt_u16 period_upper;
  alt_u32 timer_period;
  alt_u32 latency_period;

  printf("Starting internal interrupt roundtrip performance test.\n");
  timer_interrupt_latency_init ((void *)LATENCY_TIMER_BASE,LATENCY_TIMER_IRQ_INTERRUPT_CONTROLLER_ID,LATENCY_TIMER_IRQ);
  interrupt_watch_value = 0xFEEDFACE;
  PERF_RESET (PERF_COUNTER_BASE);
  PERF_START_MEASURING (PERF_COUNTER_BASE);
  PERF_BEGIN (PERF_COUNTER_BASE,1);
  
  while (interrupt_watch_value == 0xFEEDFACE) {
  /* wait for interrupt */
  }
  PERF_END (PERF_COUNTER_BASE,1);
  PERF_STOP_MEASURING (PERF_COUNTER_BASE);
  //perf_print_formatted_report (PERF_COUNTER_BASE, ALT_CPU_FREQ , 1 , "SECTION1");

  /* Calculate the latency by minus the timer period */
  period_lower = IORD_ALTERA_AVALON_TIMER_PERIODL(LATENCY_TIMER_BASE);
  period_upper = IORD_ALTERA_AVALON_TIMER_PERIODH(LATENCY_TIMER_BASE);   
  timer_period = (((period_upper << 16)|period_lower))+1;	/*1 extra clock*/

  latency_period = (unsigned long int)perf_get_section_time((void*)PERF_COUNTER_BASE,1) - timer_period; 
  printf("\nInterrupt Time:\t%8lld clocks.\n",
        (unsigned long long)latency_period);
  printf("\nSending EOT to force an exit.%c",EOT);

  return 0;
}

#ifdef ALT_ENHANCED_INTERRUPT_API_PRESENT
void timer_interrupt_latency_init (void* base, alt_u32 irq_controller_id, alt_u32 irq)
{
  /* Register the interrupt */
  alt_ic_isr_register(irq_controller_id, irq, timer_interrupt_latency_irq, base, NULL); 

  /* Start timer */
  IOWR_ALTERA_AVALON_TIMER_CONTROL(base, ALTERA_AVALON_TIMER_CONTROL_ITO_MSK 
  | ALTERA_AVALON_TIMER_CONTROL_START_MSK);
}
#else
void timer_interrupt_latency_init (void* base, alt_u32 irq)
{
  /* Register the interrupt */
  alt_irq_register(irq, base, timer_interrupt_latency_irq);
   
  /* Start timer */
  IOWR_ALTERA_AVALON_TIMER_CONTROL(base, ALTERA_AVALON_TIMER_CONTROL_ITO_MSK 
  | ALTERA_AVALON_TIMER_CONTROL_START_MSK);
}
#endif
#ifdef ALT_ENHANCED_INTERRUPT_API_PRESENT
void timer_interrupt_latency_irq (void* base)
{
  /* Clear TO bit in status register */
  IOWR_ALTERA_AVALON_TIMER_STATUS (base, 0);

  /*Stop timer */
  IOWR_ALTERA_AVALON_TIMER_CONTROL (base, ALTERA_AVALON_TIMER_CONTROL_STOP_MSK);	
  interrupt_watch_value = 0xFACEFEED;
}
#else
void timer_interrupt_latency_irq (void* base, alt_u32 id)
{
  /* Clear TO bit in status register */
  IOWR_ALTERA_AVALON_TIMER_STATUS (base, 0);

  /*Stop timer */
  IOWR_ALTERA_AVALON_TIMER_CONTROL (base, ALTERA_AVALON_TIMER_CONTROL_STOP_MSK);	
  interrupt_watch_value = 0xFACEFEED;
}
#endif

