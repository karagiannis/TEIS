#!/bin/sh

#
# This script runs the software for the collateral included with the AN-595 application note.
#

#
# Usage statement function.
#
usage() {
  echo ""
  echo "You must pass at least one argument to this script."
  echo ""
  echo "USAGE: ${0} [--VIC_DaisyChain_Example|--VIC_Example|--VIC_ISRnVectorTable_Example|--VIC_noVIC_Example|--all]"
  echo "                                   NOTE: Multiple arguments accepted." 
  echo ""
}

#
# Option variables.
#
dc_example=
vic_example=
isr_vector_example=
novic_example=

#
# Parse Options.
#

if [ $# == 0 ] ; then
  usage
  exit 0
fi

while test $# != 0 
do

  case "$1" in
  -a|--a|--all|--prog_all)
    dc_example=1
    vic_example=1
    isr_vector_example=1
    novic_example=1
    shift
    ;;
  -dc|--dc|-dc_example|--dc_example|--VIC_DaisyChain_Example)
    dc_example=1
    shift
    ;;
  -v|--v|-vic|--vic|--vic_example|--VIC_Example)
    vic_example=1
    shift
    ;;
  -isr|--isr|-isr_vector_example|--isr_vector_example|--VIC_ISRnVectorTable_Example)
    isr_vector_example=1
    shift
    ;;
  -n|--n|-novic_example|--novic_example|--VIC_noVIC_Example)
    novic_example=1
    shift
    ;;
  -*)
    usage
    exit 0
    ;;
  esac
done


#
# Run software routines
#

echo ""
echo "Running software..."
echo ""
echo ""
if [ ${dc_example} ] ; then
  DESIGN_EXAMPLE_DIR=VIC_DaisyChain_Example
  echo ""
  echo "Running for $DESIGN_EXAMPLE_DIR"
  pushd $DESIGN_EXAMPLE_DIR/software_examples/app/vic_test
  nios2-configure-sof -C ../../../ && nios2-download -g vic_test.elf && nios2-terminal
  popd
  echo ""
fi
if [ ${vic_example} ] ; then
  DESIGN_EXAMPLE_DIR=VIC_Example
  echo ""
  echo "Running for $DESIGN_EXAMPLE_DIR"
  pushd $DESIGN_EXAMPLE_DIR/software_examples/app/vic_test
  nios2-configure-sof -C ../../../ && nios2-download -g vic_test.elf && nios2-terminal
  popd
  echo ""
fi 
if [ ${isr_vector_example} ] ; then
  DESIGN_EXAMPLE_DIR=VIC_ISRnVectorTable_Example
  echo ""
  echo "Running for $DESIGN_EXAMPLE_DIR"
  pushd $DESIGN_EXAMPLE_DIR/software_examples/app/vic_test
  nios2-configure-sof -C ../../../ && nios2-download -g vic_test.elf && nios2-terminal
  popd
  echo ""
fi
if [ ${novic_example} ] ; then
  DESIGN_EXAMPLE_DIR=VIC_noVIC_Example
  echo ""
  echo "Running for $DESIGN_EXAMPLE_DIR"
  pushd $DESIGN_EXAMPLE_DIR/software_examples/app/vic_test
  nios2-configure-sof -C ../../../ && nios2-download -g vic_test.elf && nios2-terminal
  popd
  echo ""
fi
echo ""
echo ""
echo "Done..."
echo ""
echo ""
