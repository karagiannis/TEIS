Contents:
=====
ReadMe.txt => This file.
MPU_Design_limit => Limit design directory.
MPU_Design_msk => Mask design directory.
=====

Info:
=====
- SOFs and everything you need to re-generate them are in the top levels of the
design directories. 
- The software_examples sub-directories (and their contents) are identical.

software_examples info.:
=====
- Common BSP called "mpu_example_bsp".
  - Located in software_examples/bsp/mpu_example_bsp, where there is a
    create-this-bsp script to generate it.
- One example application called "mpu_basic".
  - Configures several data and instruction regions and runs a simple program.
  - Located in software_examples/app/mpu_basic, where there is a
    create-this-app script to generate it.
- One example application called "mpu_exc_detection".
  - Configures the same data and instruction regions, and an exception
    handler.  Detects some of the proper exceptions.
  - Located in software_examples/app/mpu_exc_detection, where there is a
    create-this-app script to generate it.

Things to remember:
=====
1.  It's all about the configured minumum region size...
  - Most every parameter is in increments of or with this knowledge in mind.
2.  Region's must be aligned to a power of 2 and an increment of their size.
  - For example, a 16k region, must start at an integer increment of 16k...
    - 0, 16k, 32k, would all be valid starting addresses, but 8k would not.
3.  Choose good address locations when designing in SOPC Builder.
  - The MPU will function better if you place your components with it in mind.
    - For the most part, keep in mind the first two rules when doing this.
4.  Regions can overlap each other.
  - Higher priority exclusion/permissive regions can be placed inside lower
    priority permissive/exclusion regions to gain the desired effect.
    - For instance, a higher priority exclusion region can be placed inside of
      another region to detect something like stack overflow.
   
