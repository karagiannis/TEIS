/* Tests the MPU by configuring it and running a simple hello_world program. */

#include "sys/alt_stdio.h"
#include "mpu_utils.h"
#include "io.h"
#include "unistd.h"

int main() 
{
  // Clear the MPU to "safe" (allow everything) state.
  nios2_mpu_data_init();
  nios2_mpu_inst_init();
  //nios2_mpu_init( MPU_DATA );
  //nios2_mpu_init( MPU_INST );

  nios2_mpu_enable();

  alt_putstr("Hello from a simple MPU-Enabled Nios II System!.\n");

  IOWR(0x20000,400,0xfeedface);
  IOWR(0x20000,2000,0xfeedface);
  IOWR_8DIRECT(0x20000,0xeff,0x40);
  
  int val1 = IORD(0x20000,400);
  int val2 = IORD(0x20000,2000);
  char val3 = IORD_8DIRECT(0x20000,0xeff);

  alt_printf("val1 = 0x%x, val2 = 0x%x, val3 = 0x%c.\n", val1, val2, val3); 
}
