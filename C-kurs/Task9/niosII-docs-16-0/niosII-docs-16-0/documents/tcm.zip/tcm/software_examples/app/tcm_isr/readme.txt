This directory contains the script called create-this-app that builds
tcm application.  To understand the simple sequence of operations
required to build a working Nios II application, please read the 
contents of the create-this-app script.
