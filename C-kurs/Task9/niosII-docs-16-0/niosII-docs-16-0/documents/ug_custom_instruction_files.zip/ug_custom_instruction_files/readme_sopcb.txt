Custom Instruction User Guide - readme.txt

This file contains the following sections:

o  Tool Requirements
o  Project Directory Names
o  Quartus II Project Setup
o  Nios II Software Build Flow


Tool Requirements
=============

The design used in this user guide requires the following:

- Quartus II software version 10.1 or later
- Nios II Embedded Design Suite version 10.1 or later
- IP Design Suite version 10.1 or later
- Modelsim-Altera tool version 6.4g or later (if you wish to simulate
  the design)


Please contact your local sales representative if you do not have one of these
software tools.


Project Directory Names
=================

These files are created on your local harddrive when you extract ciug_de_sopc.zip.

[ug_custom_instruction_files]
|----[crc_hw]
      |----CRC_Component.v
      |----CRC_Custom_Instruction.v
|----[crc_sw]
      |----[app]
            |----create-this-app
            |----[src]
                  |----ci_crc.c
                  |----crc.c
                  |----crc_main.c
                  |----ci_crc.h
                  |----crc.h
     |----[bsp]
           |----create-this-bsp


Quartus II Project Setup
=================

These steps will guide you in opening the Quartus II project.

1. Extract the ciug_de_sopc.zip archive file to your local harddrive. This location is referred to as <archive_dir>.

2. Copy the entire folder of Nios II Ethernet Standard Design Example for your particular 
    development kit to a location where it can be edited. This location is referred to as <project_dir>.
    The example files can be found at http://www.altera.com/support/examples/nios2/exm-net-std-de.html .

3. Copy both crc_hw and crc_sw folders from <archive_dir> to <project_dir>.

4. Open Quartus II software.

5. On the File menu, click Open Project.

6. Browse to <project_dir>. Select niosii_ethernet_standard_<board-type>.qpf file and click Open.

You are now ready to create a new custom instruction for the system. Refer to the Custom 
Instruction User Guide for step-by-step instructions.


Nios II Software Build Flow
====================

These steps will guide you through building the software example.

1. Open a Nios II command shell and change directory to <project_dir>.

2. Configure the FPGA by running the following command:
     nios2-configure-sof niosii_ethernet_standard_<board-type>.sof

3. After the configuration is done, change the directory to:
     <project_dir>/crc_sw/app

4. Run the following command for building the application software project:
     ./create-this-app

5. When it is done, you can now run the application with the command:
     nios2-download -g crc.elf && nios2-terminal




Last updated January 2011
Copyright � 2011 Altera Corporation. All rights reserved.
