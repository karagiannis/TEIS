#define ALT_ASM_SRC

#include "system.h"
#include "altera_avalon_timer_regs.h"
#include "os/alt_hooks.h"

#define TIMER_STATUS_ADDR            (LATENCY_TIMER_BASE + (ALTERA_AVALON_TIMER_STATUS_REG * 4))
#define TIMER_CONTROL_ADDR            (LATENCY_TIMER_BASE + (ALTERA_AVALON_TIMER_CONTROL_REG * 4))

.macro MY_ISR vec_size

begin_isr:
    ALT_OS_INT_ENTER_ASM        /* Notify the operating system that we are at interrupt level.  */

    rdprs sp, sp, 0                /* Get SP from previous register set. */

    /*IOWR_ALTERA_AVALON_TIMER_STATUS (base, 0);*/
    movhi r3, %hi(TIMER_STATUS_ADDR)
    ori r3, r3, %lo(TIMER_STATUS_ADDR)
    stwio zero, 0(r3)

    /*IOWR_ALTERA_AVALON_TIMER_CONTROL (base, ALTERA_AVALON_TIMER_CONTROL_STOP_MSK);*/
    movhi r3, %hi(TIMER_CONTROL_ADDR)
    ori r3, r3, %lo(TIMER_CONTROL_ADDR)
    movi r2, ALTERA_AVALON_TIMER_CONTROL_STOP_MSK
    stwio r2, 0(r3)

    /*interrupt_watch_value = 0xFACEFEED;*/
    movhi r2, %hi(0xfacefeed)
    ori r2, r2, %lo(0xfacefeed)
    stw   r2, %gprel(interrupt_watch_value)(gp)
		
    ALT_OS_INT_EXIT_ASM         /*Notify the operating system that interrupt processing is complete. */
    addi ea, ea, -4             /* instruction that caused exception */
    eret
end_isr:
    .zero  (\vec_size-(end_isr-begin_isr))
.endm

