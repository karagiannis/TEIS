Directory Structure
=====
This directory contains 4 Designs in the following sub-directories:
  *VIC_Example 
    - Basic VIC usage example
  *VIC_noVIC_Example
    - Same structure as the VIC_Example, but with no VIC...for performance comparison purposes
  *VIC_DaisyChain_Example
    - Adds an additional VIC to the VIC_Example design
  *VIC_ISRnVectorTable_Example
    - Modification to VIC_Example with the timer ISR located in the vector table
NOTE:  There is also a shell script named run_sw.sh in the top-level directory that automates running each, all, or any number of the example's software code.  The script makes the assumption that you have only one JTAG cable connected to your PC.
=====

Design Description
=====
All designs contain the Qsys hardware design and top-level wrapper Verilog along with the Quartus II files
necessary for programming/configuring a Cyclone V SoC developement kit.  The software necessary
to demonstrate the performance benefit gained from using the VIC is also there to run.
=====

Porting Considerations
=====
These designs have been updated from Cyclone III NEEK to the Cyclone V SoC. Hence, they were constructed with portability in mind.  Because only on-chip memory is used, connecting the clock and reset signals from the Qsys generated module should be your only 
porting concern.
=====

Run the designs (Assumes that you have one JTAG connection)
=====
1.  Connect your Cyclone V SoC to your PC using a standard USB cable.
2.  Apply power to your Cyclone V SoC board.
3.  From within a Nios II Command Shell, change directories to the
      software_examples/app/ subdirectory of the example
      software that you'd like to run.
4.  Download the SOF  
      - Type 'nios2-configure-sof -C ../../ -d 2' from within the
        subdirectory specified in step 3.
5.  Download the ELF, start the processor, and a connection to it (terminal).
      - Type 'nios2-download -g vic_test.elf && nios2-terminal'
      - You'll receive output similar to the following:
-----
Starting VIC Example roundtrip performance test.

Interrupt Time:       35 clocks.

Sending EOT to force an exit.
-----
=====

Please refer to Embedded IP user guide VIC core chapter for further information regarding these
designs and the VIC.

Release History
=======
Version 2.0
------------
Updated devices used to Cyclone V SoC

Version 1.0
------------
Initial release 
