#include <stdio.h>
#include "altera_avalon_performance_counter.h"
#include "system.h"
#include "altera_avalon_timer_regs.h"
#include "sys/alt_irq.h"
#include "sys/alt_cache.h"

#ifdef ALT_ENHANCED_INTERRUPT_API_PRESENT
void timer_interrupt_latency_init (alt_u32 base, alt_u32 irq_controller_id, alt_u32 irq, void* context);
void timer1_interrupt_latency_irq (void* context);
void timer2_interrupt_latency_irq (void* context);
#else
void timer_interrupt_latency_init (alt_u32 base, alt_u32 irq, void* context);
void timer_interrupt_latency_irq (void* context, alt_u32 irq);
#endif

/* Volatile "watch" values. */
volatile alt_u32 interrupt_watch_value;

#define EOT 0x4

#define PERF_COUNTER_BASE PERFORMANCE_COUNTER_0_BASE

int main()
{
  alt_u16 period_lower;
  alt_u16 period_upper;
  alt_u32 timer_period;
  alt_u32 latency_period;
  alt_u64 perf_counter_time;

  printf("Starting DaisyChain VIC performance test.\n");

  // Stop both timers.
  IOWR_ALTERA_AVALON_TIMER_CONTROL (LATENCY_TIMER1_BASE, ALTERA_AVALON_TIMER_CONTROL_STOP_MSK);
  IOWR_ALTERA_AVALON_TIMER_CONTROL (LATENCY_TIMER2_BASE, ALTERA_AVALON_TIMER_CONTROL_STOP_MSK);

  // Timer 1 latency test.
  interrupt_watch_value = 0xFEEDFACE;
  timer_interrupt_latency_init (LATENCY_TIMER1_BASE,LATENCY_TIMER1_IRQ_INTERRUPT_CONTROLLER_ID,LATENCY_TIMER1_IRQ, (void*)&interrupt_watch_value);
  PERF_RESET (PERF_COUNTER_BASE);
  PERF_START_MEASURING (PERF_COUNTER_BASE);
  PERF_BEGIN (PERF_COUNTER_BASE,1);
  
  while (interrupt_watch_value == 0xFEEDFACE) {
  // wait for interrupt 
  }
  PERF_END (PERF_COUNTER_BASE,1);
  PERF_STOP_MEASURING (PERF_COUNTER_BASE);

  // Calculate the latency by subtracting the timer period
  period_lower = IORD_ALTERA_AVALON_TIMER_PERIODL(LATENCY_TIMER1_BASE);
  period_upper = IORD_ALTERA_AVALON_TIMER_PERIODH(LATENCY_TIMER1_BASE);   
  timer_period = (((period_upper << 16)|period_lower))+1;// 1 extra clock

  perf_counter_time = perf_get_section_time((int*)PERF_COUNTER_BASE, 1);
  latency_period = (alt_u64)perf_get_section_time((int*)PERF_COUNTER_BASE,1) - timer_period; 
  printf("\nPrimary VIC (vic1) Interrupt Time:\t%8lld clocks.",
        (unsigned long long)latency_period);
  //Flush the caches to ensure accurate performance counts. 
  alt_dcache_flush_all();
  alt_icache_flush_all();
  // Timer 2 latency test.
  PERF_RESET (PERF_COUNTER_BASE);
  interrupt_watch_value = 0xFEEDFACE;
  timer_interrupt_latency_init (LATENCY_TIMER2_BASE,LATENCY_TIMER2_IRQ_INTERRUPT_CONTROLLER_ID,LATENCY_TIMER2_IRQ, (void*)&interrupt_watch_value);
  PERF_START_MEASURING (PERF_COUNTER_BASE);
  PERF_BEGIN (PERF_COUNTER_BASE,1);

  while (interrupt_watch_value == 0xFEEDFACE) {
  // wait for interrupt 
  }
  PERF_END (PERF_COUNTER_BASE,1);
  PERF_STOP_MEASURING (PERF_COUNTER_BASE);
  //perf_print_formatted_report (PERF_COUNTER_BASE, ALT_CPU_FREQ , 1 , "SECTION1");

  // Calculate the latency by subtracting the timer period 
  period_lower = IORD_ALTERA_AVALON_TIMER_PERIODL(LATENCY_TIMER2_BASE);
  period_upper = IORD_ALTERA_AVALON_TIMER_PERIODH(LATENCY_TIMER2_BASE);
  timer_period = (((period_upper << 16)|period_lower))+1;       //1 extra clock

  perf_counter_time = perf_get_section_time((void*)PERF_COUNTER_BASE, 1);
  latency_period = (unsigned long int)perf_get_section_time((void*)PERF_COUNTER_BASE,1) - timer_period;
  printf("\nDaisychained VIC (vic2) Interrupt Time:\t%8lld clocks.\n\n",
        (unsigned long long)latency_period);
  printf("Test Run Complete...\n");
  printf("Sending EOT to force an exit.%c",EOT);

  return 0;
}

#ifdef ALT_ENHANCED_INTERRUPT_API_PRESENT
void timer_interrupt_latency_init (alt_u32 base, alt_u32 irq_controller_id, alt_u32 irq, void* context)
{
  volatile int watch_value = 0;
  volatile int* watch_value_ptr = (volatile int*)context;
  watch_value = *watch_value_ptr;
  /* Register the interrupt */
  if( base == LATENCY_TIMER1_BASE)
    alt_ic_isr_register(irq_controller_id, irq, timer1_interrupt_latency_irq, context, NULL); 
  else
    alt_ic_isr_register(irq_controller_id, irq, timer2_interrupt_latency_irq, context, NULL); 

  /* Start timer */
  IOWR_ALTERA_AVALON_TIMER_CONTROL(base, ALTERA_AVALON_TIMER_CONTROL_ITO_MSK 
  | ALTERA_AVALON_TIMER_CONTROL_START_MSK);
}
#else
void timer_interrupt_latency_init (void* base, alt_u32 irq, void* context)
{
  /* Register the interrupt */
  if( base == LATENCY_TIMER1_BASE)
    alt_irq_register(irq, timer1_interrupt_latency_irq, context);
  else
    alt_irq_register(irq, timer2_interrupt_latency_irq, context);
   
  /* Start timer */
  IOWR_ALTERA_AVALON_TIMER_CONTROL(base, ALTERA_AVALON_TIMER_CONTROL_ITO_MSK 
  | ALTERA_AVALON_TIMER_CONTROL_START_MSK);
}
#endif
#ifdef ALT_ENHANCED_INTERRUPT_API_PRESENT
void timer1_interrupt_latency_irq (void* context)
{
  /* Clear TO bit in status register */
  IOWR_ALTERA_AVALON_TIMER_STATUS (LATENCY_TIMER1_BASE, 0);

  /*Stop timer */
  IOWR_ALTERA_AVALON_TIMER_CONTROL (LATENCY_TIMER1_BASE, ALTERA_AVALON_TIMER_CONTROL_STOP_MSK);
  /* Assign value pointed to by context to 0xFACEFEED. */
  *(volatile int*)context = 0xFACEFEED;
}
#else
void timer1_interrupt_latency_irq (void* context, alt_u32 irq)
{
  /* Clear TO bit in status register */
  IOWR_ALTERA_AVALON_TIMER_STATUS (base, 0);

  /*Stop timer */
  IOWR_ALTERA_AVALON_TIMER_CONTROL (base, ALTERA_AVALON_TIMER_CONTROL_STOP_MSK);
  /* Assign value at context to 0xFACEFEED. */
  *(volatile int)context = 0xFACEFEED;
}
#endif
#ifdef ALT_ENHANCED_INTERRUPT_API_PRESENT
void timer2_interrupt_latency_irq (void* context)
{
  /* Clear TO bit in status register */
  IOWR_ALTERA_AVALON_TIMER_STATUS (LATENCY_TIMER2_BASE, 0);

  /*Stop timer */
  IOWR_ALTERA_AVALON_TIMER_CONTROL (LATENCY_TIMER2_BASE, ALTERA_AVALON_TIMER_CONTROL_STOP_MSK);
  /* Assign value pointed to by context to 0xFACEFEED. */
  *(volatile int*)context = 0xFACEFEED;
}
#else
void timer2_interrupt_latency_irq (void* context, alt_u32 irq)
{
  /* Clear TO bit in status register */
  IOWR_ALTERA_AVALON_TIMER_STATUS (LATENCY_TIMER2_BASE, 0);

  /*Stop timer */
  IOWR_ALTERA_AVALON_TIMER_CONTROL (LATENCY_TIMER2_BASE, ALTERA_AVALON_TIMER_CONTROL_STOP_MSK);
  /* Assign value at context to 0xFACEFEED. */
  *(volatile int)context = 0xFACEFEED;
}
#endif


