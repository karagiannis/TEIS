<!-- Begin GA Tracking Code added by E-Nor-->
var host = document.location.hostname;
var hostname = host.match(/(([^.\/]+\.[^.\/]{2,3}\.[^.\/]{2})|(([^.\/]+\.)[^.\/]{2,4}))(\/.*)?$/)[1];
hostname = hostname.toLowerCase();

var _gaq = _gaq || [];
_gaq.push(['_setAccount', 'UA-31812208-1']);
_gaq.push(['_setDomainName', hostname]);
_gaq.push(['_setAllowLinker', true]);
_gaq.push(['_trackPageview']);

(function() {
var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
})();
<!-- End GA Tracking Code -->

<!-- Begin code for Demandbase-->
(function(d,b,a,s,e){ var t = b.createElement(a),
    fs = b.getElementsByTagName(a)[0]; t.async=1; t.id=e;
    t.src=('https:'==document.location.protocol ? 'https://' : 'http://') + s;
    fs.parentNode.insertBefore(t, fs); })
(window,document,'script','scripts.demandbase.com/0CiRlDNS.min.js','demandbase_js_lib');
<!-- End code for Demandbase-->