/* --------------------------------------------------------------------
-- Company: TEIS AB
-- Engineer: Lasse Karagiannis
--
-- Create Date: 2016-10-01
-- Design Name: uppgift_4a
-- Target Devices: BeMicro Max 10 board
-- Tool versions: Quartus v16 and Eclipse
--
-- In_signals:
-- key_in -- button input button-0,-1,-2,3-
Out_signals:
-- LED -- D1 - D3


-------------------------------------------------------------------

 */

#include <io.h>
#include <alt_types.h>
#include <system.h>
#include "altera_avalon_pio_regs.h"



#include <stdio.h>

int main()
{

	alt_u32 key_in, LEDs,temp;

	// States in the design
	enum state {Input_KEY_state, Working_State,
	Output_LED_State_0,
	Output_LED_State_1,Output_LED_State_2,
   End_state};

	enum state current_state;

	current_state = Input_KEY_state;
	IOWR_ALTERA_AVALON_PIO_DATA(PIO_OUT_LED_BASE,0xFF);

	while(1) // Loop for ever
	{

		key_in = IORD_ALTERA_AVALON_PIO_DATA(PIO_IN_KEY_BASE);
		switch (current_state) {
		//Start
			case Input_KEY_state:
				// Om en knapp �r nertryckt byt till tillst�ndet �working_state*� annars
				//stanna kvar i samma tillst�nd.
				if(((key_in & 0xFF) == 0xFE) ||((key_in  & 0xFF) ==0xFD) ||((key_in  & 0xFF) ==0xFB))
					current_state = Working_State;
				break;

	case Working_State:
	// Byt till tillst�ndet Output_LED_State_X (Beroende av vilken knapp som �r tryckt)
		if ((key_in & 0xFF) == 0xFE)
			current_state = Output_LED_State_0;
		if ((key_in & 0xFF) == 0xFD)
					current_state = Output_LED_State_1;
		if ((key_in & 0xFF) == 0xFB)
					current_state = Output_LED_State_2;
		break;

	case Output_LED_State_0:
	// Toggla enbart den lysdioden det g�ller, de �vriga ska inte p�verkas
	// byt till tillst�ndet End_state
		LEDs = IORD_ALTERA_AVALON_PIO_DATA(PIO_OUT_LED_BASE);
		LEDs ^= 0x01;
		IOWR_ALTERA_AVALON_PIO_DATA(PIO_OUT_LED_BASE,LEDs);
		if(LEDs==0xFE)
			printf("Led0 lyser");
		else
			printf("Led0 lyser ej");
		current_state = End_state;
		break;
	case Output_LED_State_1:
	// Toggla enbart den lysdioden det g�ller, de �vriga ska inte p�verkas
	// byt till tillst�ndet End_state
		LEDs = IORD_ALTERA_AVALON_PIO_DATA(PIO_OUT_LED_BASE);
		LEDs ^= 0x02;
		IOWR_ALTERA_AVALON_PIO_DATA(PIO_OUT_LED_BASE,LEDs);
		if(LEDs == 0xFD)
			printf("Led1 lyser");
		else
			printf("Led1 lyser ej");
		current_state = End_state;
		break;
	case Output_LED_State_2:
	// Toggla enbart den lysdioden det g�ller, de �vriga ska inte p�verkas
	// byt till tillst�ndet End_state
		LEDs = IORD_ALTERA_AVALON_PIO_DATA(PIO_OUT_LED_BASE);
		LEDs ^= 0x04;
		IOWR_ALTERA_AVALON_PIO_DATA(PIO_OUT_LED_BASE,LEDs);
		if(LEDs == 0Xfb)
			printf("Led2 lyser");
		else
			printf("Led2 lyser ej");
		current_state = End_state;
		break;

	case End_state:
	// Om ingen tryckknapp �r nertryckt, byt till Input_key_state annars stanna
	//kvar i End_state.
		if(((key_in & 0xFF) == 0xFE) ||((key_in  & 0xFF) ==0xFD) ||((key_in  & 0xFF) ==0xFB))
			current_state = End_state;
		else
			current_state = Input_KEY_state;

		break;
	};//end switch
}; // End loop

  return 0;
}
