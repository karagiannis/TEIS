#ifndef ERROR_LOOP_H_
#define ERROR_LOOP_H_

// function prototypes from src/error_loop.c
void error_loop(void);

#endif /*ERROR_LOOP_H_*/
